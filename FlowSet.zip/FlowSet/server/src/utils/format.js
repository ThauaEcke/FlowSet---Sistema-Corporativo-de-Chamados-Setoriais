function formatarDataBR(isoDate) {
  if (!isoDate) return '-';
  const d = isoDate instanceof Date ? isoDate : new Date(isoDate);
  if (Number.isNaN(d.getTime())) return '-';
  return d.toLocaleDateString('pt-BR');
}

function formatarPrazoRow(prazo) {
  if (prazo == null) return '-';
  if (typeof prazo === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(prazo)) {
    const [y, m, day] = prazo.split('-');
    return `${day}/${m}/${y}`;
  }
  return formatarDataBR(prazo);
}

/** Monta objeto no formato esperado pelo front (app.js — listagem / detalhes). */
function chamadoParaFront(row) {
  const dataAbertura = row.data_abertura
    ? new Date(row.data_abertura).toLocaleDateString('pt-BR')
    : '-';
  return {
    id: row.numero,
    setorOrigem: row.setor_origem || row.setorOrigem,
    setorDestino: row.setor_destino || row.setorDestino,
    status: row.status,
    prioridade: row.prioridade,
    prazo: formatarPrazoRow(row.prazo),
    tipo: row.tipo,
    descricao: row.descricao,
    dataAbertura,
    solicitanteNome: row.solicitante_nome || null,
    solicitanteEmail: row.solicitante_email || null,
    anexos: Array.isArray(row.anexos_json) ? row.anexos_json : [],
    resolucao: row.resolucao_texto || null,
  };
}

module.exports = { formatarDataBR, formatarPrazoRow, chamadoParaFront };

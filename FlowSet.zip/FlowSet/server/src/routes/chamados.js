const express = require('express');
const { pool } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { mapTipo, mapPrioridade } = require('../utils/chamadoMaps');
const { gerarProximoNumero } = require('../utils/nextNumero');
const { chamadoParaFront } = require('../utils/format');
const {
  sendResolucaoEmail,
  sendChamadoStatusEmail,
  sendChamadoCriadoSolicitanteEmail,
} = require('../utils/email');

const router = express.Router();

/** Valores aceitos pelo CHECK chk_chamados_status no banco. */
const STATUS_VALIDOS = [
  'Aberto',
  'Em atendimento',
  'Finalizado',
  'Crítico',
  'Aguardando',
  'Cancelado',
];

async function resolveSetorId(codigo) {
  if (!codigo) return null;
  const { rows } = await pool.query(
    `SELECT id FROM setores WHERE codigo = $1 AND ativo = TRUE`,
    [String(codigo).trim()]
  );
  return rows[0] ? rows[0].id : null;
}

/** E-mails de todos os usuários ativos do setor (qualquer perfil), para notificação por SMTP. */
async function getEmailsResponsaveisSetor(setorId) {
  if (!setorId) return [];
  const { rows } = await pool.query(
    `
    SELECT email
    FROM usuarios
    WHERE setor_id = $1
      AND ativo = TRUE
      AND email IS NOT NULL
      AND trim(email) <> ''
    `,
    [setorId]
  );
  const emails = rows.map((r) => String(r.email || '').trim()).filter(Boolean);
  return Array.from(new Set(emails));
}

function isAdminUser(user) {
  return String((user && user.perfil) || '').trim().toLowerCase() === 'administrador';
}

function userCanAccessChamado(user, chamadoRow) {
  if (!user || !chamadoRow) return false;
  if (isAdminUser(user)) return true;
  const abriu = Number(chamadoRow.usuario_abertura_id) === Number(user.id);
  const recebeu = user.setor_id != null && Number(chamadoRow.setor_responsavel_id) === Number(user.setor_id);
  return abriu || recebeu;
}

/** GET /api/chamados — listagem (requer login). */
router.get('/', requireAuth, async (req, res) => {
  try {
    const params = [];
    let filtroEscopo = '';
    if (!isAdminUser(req.user)) {
      filtroEscopo = 'AND (c.usuario_abertura_id = $1 OR ($2::int IS NOT NULL AND c.setor_responsavel_id = $2::int))';
      params.push(req.user.id, req.user.setor_id || null);
    }
    const { rows } = await pool.query(`
      SELECT c.numero, c.status, c.prioridade, c.descricao, c.prazo, c.data_abertura, c.tipo, c.anexos_json, c.resolucao_texto,
             u.nome AS solicitante_nome, u.email AS solicitante_email,
             s1.nome AS setor_origem, s2.nome AS setor_destino
      FROM chamados c
      JOIN setores s1 ON c.setor_solicitante_id = s1.id
      JOIN setores s2 ON c.setor_responsavel_id = s2.id
      LEFT JOIN usuarios u ON c.usuario_abertura_id = u.id
      WHERE c.excluido_em IS NULL
      ${filtroEscopo}
      ORDER BY c.data_abertura DESC
    `, params);
    return res.json({ chamados: rows.map(chamadoParaFront) });
  } catch (err) {
    console.error('[chamados list]', err);
    return res.status(500).json({ error: 'Erro ao listar chamados.' });
  }
});

/** GET /api/chamados/:numero — detalhe (requer login). */
router.get('/:numero', requireAuth, async (req, res) => {
  try {
    const numero = decodeURIComponent(req.params.numero);
    const params = [numero];
    let filtroEscopo = '';
    if (!isAdminUser(req.user)) {
      filtroEscopo = 'AND (c.usuario_abertura_id = $2 OR ($3::int IS NOT NULL AND c.setor_responsavel_id = $3::int))';
      params.push(req.user.id, req.user.setor_id || null);
    }
    const { rows } = await pool.query(
      `
      SELECT c.id, c.numero, c.status, c.prioridade, c.descricao, c.prazo, c.data_abertura, c.tipo, c.anexos_json, c.resolucao_texto,
             u.nome AS solicitante_nome, u.email AS solicitante_email,
             s1.nome AS setor_origem, s2.nome AS setor_destino
      FROM chamados c
      JOIN setores s1 ON c.setor_solicitante_id = s1.id
      JOIN setores s2 ON c.setor_responsavel_id = s2.id
      LEFT JOIN usuarios u ON c.usuario_abertura_id = u.id
      WHERE c.numero = $1 AND c.excluido_em IS NULL
      ${filtroEscopo}
      `,
      params
    );
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Chamado não encontrado.' });
    }
    return res.json({ chamado: chamadoParaFront(rows[0]) });
  } catch (err) {
    console.error('[chamados get]', err);
    return res.status(500).json({ error: 'Erro ao buscar chamado.' });
  }
});

/** POST /api/chamados — abrir chamado (requer login). */
router.post('/', requireAuth, async (req, res) => {
  try {
    const body = req.body || {};
    const setorSol = body.setor_solicitante || body.setorSolicitante;
    const setorResp = body.setor_responsavel || body.setorResponsavel;
    const tipoRaw = body.tipo;
    const prioridadeRaw = body.prioridade;
    const descricao = body.descricao;
    const prazo = body.prazo;
    const anexos = Array.isArray(body.anexos) ? body.anexos : [];

    const tipo = mapTipo(tipoRaw);
    const prioridade = mapPrioridade(prioridadeRaw);

    if (!setorSol || !setorResp) {
      return res.status(400).json({ error: 'Informe setor solicitante e setor responsável (código).' });
    }
    if (!tipo) {
      return res.status(400).json({ error: 'Informe um tipo de solicitação válido.' });
    }
    if (!descricao || !String(descricao).trim()) {
      return res.status(400).json({ error: 'Informe a descrição.' });
    }

    const idSol = await resolveSetorId(setorSol);
    const idResp = await resolveSetorId(setorResp);
    if (!idSol || !idResp) {
      return res.status(400).json({ error: 'Setor inválido. Use o código (ex.: ti, comercial).' });
    }

    const numero = await gerarProximoNumero(pool);
    const prazoDate = prazo ? String(prazo).slice(0, 10) : null;

    const { rows } = await pool.query(
      `
      INSERT INTO chamados (
        numero, setor_solicitante_id, setor_responsavel_id, usuario_abertura_id,
        tipo, prioridade, descricao, anexos_json, prazo, status
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb, $9, 'Aberto')
      RETURNING id
      `,
      [
        numero,
        idSol,
        idResp,
        req.user.id,
        tipo,
        prioridade,
        String(descricao).trim(),
        JSON.stringify(anexos),
        prazoDate || null,
      ]
    );

    const chamadoId = rows[0].id;
    await pool.query(
      `
      INSERT INTO historico (chamado_id, usuario_id, tipo_alteracao, valor_anterior, valor_novo)
      VALUES ($1, $2, 'abertura', NULL, $3)
      `,
      [chamadoId, req.user.id, numero]
    );

    const { rows: full } = await pool.query(
      `
      SELECT c.numero, c.status, c.prioridade, c.descricao, c.prazo, c.data_abertura, c.tipo, c.anexos_json, c.resolucao_texto,
             u.nome AS solicitante_nome, u.email AS solicitante_email,
             s1.nome AS setor_origem, s2.nome AS setor_destino
      FROM chamados c
      JOIN setores s1 ON c.setor_solicitante_id = s1.id
      JOIN setores s2 ON c.setor_responsavel_id = s2.id
      LEFT JOIN usuarios u ON c.usuario_abertura_id = u.id
      WHERE c.id = $1
      `,
      [chamadoId]
    );

    const chamadoFront = chamadoParaFront(full[0]);
    const emailSolicitante =
      (chamadoFront.solicitanteEmail && String(chamadoFront.solicitanteEmail).trim()) ||
      (req.user.email && String(req.user.email).trim()) ||
      '';

    let emailSolicitanteNotificado = false;
    try {
      if (emailSolicitante) {
        const mailSol = await sendChamadoCriadoSolicitanteEmail({
          to: emailSolicitante,
          nome: chamadoFront.solicitanteNome || req.user.nome,
          numero: chamadoFront.id,
          setorOrigem: chamadoFront.setorOrigem,
          setorDestino: chamadoFront.setorDestino,
          tipo: chamadoFront.tipo,
          prioridade: chamadoFront.prioridade,
          prazo: chamadoFront.prazo,
          descricao: chamadoFront.descricao,
        });
        emailSolicitanteNotificado = !!mailSol.sent;
      }
    } catch (eMailSolicErr) {
      console.error('[email solicitante abertura]', eMailSolicErr);
    }

    let emailResponsaveisNotificado = false;
    try {
      const emailsResponsaveis = await getEmailsResponsaveisSetor(idResp);
      if (emailsResponsaveis.length) {
        const mailResp = await sendChamadoStatusEmail({
          to: emailsResponsaveis,
          numero: chamadoFront.id,
          status: chamadoFront.status,
          setorOrigem: chamadoFront.setorOrigem,
          setorDestino: chamadoFront.setorDestino,
          solicitanteNome: chamadoFront.solicitanteNome,
          prioridade: chamadoFront.prioridade,
          descricao: chamadoFront.descricao
        });
        emailResponsaveisNotificado = !!mailResp.sent;
      }
    } catch (eMailErr) {
      console.error('[email responsaveis abertura]', eMailErr);
    }

    return res.status(201).json({
      chamado: chamadoFront,
      emailSolicitanteNotificado,
      emailResponsaveisNotificado,
    });
  } catch (err) {
    console.error('[chamados post]', err);
    return res.status(500).json({ error: 'Erro ao abrir chamado.' });
  }
});

/** PATCH /api/chamados/:numero — atualizar status (requer login). */
router.patch('/:numero', requireAuth, async (req, res) => {
  try {
    const numero = decodeURIComponent(req.params.numero);
    const { status, resolucao } = req.body || {};
    if (!status || !String(status).trim()) {
      return res.status(400).json({ error: 'Informe o novo status.' });
    }
    const novoStatus = String(status).trim();
    if (!STATUS_VALIDOS.includes(novoStatus)) {
      return res.status(400).json({
        error: 'Status inválido.',
        permitidos: STATUS_VALIDOS,
      });
    }

    const { rows: existentes } = await pool.query(
      `SELECT id, status, usuario_abertura_id, setor_responsavel_id FROM chamados WHERE numero = $1 AND excluido_em IS NULL`,
      [numero]
    );
    if (existentes.length === 0) {
      return res.status(404).json({ error: 'Chamado não encontrado.' });
    }
    if (!userCanAccessChamado(req.user, existentes[0])) {
      return res.status(403).json({ error: 'Você não tem permissão para alterar este chamado.' });
    }
    const chamadoId = existentes[0].id;
    const statusAnterior = existentes[0].status;

    const finalizado = novoStatus.toLowerCase().includes('finalizado');
    const resolucaoTexto = resolucao && String(resolucao).trim() ? String(resolucao).trim() : null;
    if (finalizado && !resolucaoTexto) {
      return res.status(400).json({ error: 'Descreva como o chamado foi resolvido para finalizar.' });
    }
    await pool.query(
      `
      UPDATE chamados
      SET status = $1,
          resolucao_texto = CASE WHEN $2 THEN $3 ELSE resolucao_texto END,
          data_conclusao = CASE WHEN $2 THEN CURRENT_TIMESTAMP ELSE data_conclusao END
      WHERE id = $4
      `,
      [novoStatus, finalizado, resolucaoTexto, chamadoId]
    );

    await pool.query(
      `
      INSERT INTO historico (chamado_id, usuario_id, tipo_alteracao, valor_anterior, valor_novo)
      VALUES ($1, $2, 'mudanca_status', $3, $4)
      `,
      [chamadoId, req.user.id, statusAnterior, novoStatus]
    );

    const { rows: full } = await pool.query(
      `
      SELECT c.numero, c.status, c.prioridade, c.descricao, c.prazo, c.data_abertura, c.tipo, c.anexos_json, c.resolucao_texto,
             u.nome AS solicitante_nome, u.email AS solicitante_email,
             s1.nome AS setor_origem, s2.nome AS setor_destino
      FROM chamados c
      JOIN setores s1 ON c.setor_solicitante_id = s1.id
      JOIN setores s2 ON c.setor_responsavel_id = s2.id
      LEFT JOIN usuarios u ON c.usuario_abertura_id = u.id
      WHERE c.id = $1
      `,
      [chamadoId]
    );

    const chamadoFront = chamadoParaFront(full[0]);
    let emailNotificado = false;
    let emailResponsaveisNotificado = false;
    if (finalizado && chamadoFront.solicitanteEmail) {
      try {
        const emailResult = await sendResolucaoEmail({
          to: chamadoFront.solicitanteEmail,
          nome: chamadoFront.solicitanteNome,
          numero: chamadoFront.id,
          setorDestino: chamadoFront.setorDestino,
          resolucao: resolucaoTexto || chamadoFront.resolucao || ''
        });
        emailNotificado = !!emailResult.sent;
      } catch (eMailErr) {
        console.error('[email resolucao]', eMailErr);
      }
    }

    const statusNorm = String(novoStatus || '').trim().toLowerCase();
    if (statusNorm === 'aberto' || statusNorm === 'finalizado') {
      try {
        const emailsResponsaveis = await getEmailsResponsaveisSetor(existentes[0].setor_responsavel_id);
        if (emailsResponsaveis.length) {
          const mailResp = await sendChamadoStatusEmail({
            to: emailsResponsaveis,
            numero: chamadoFront.id,
            status: chamadoFront.status,
            setorOrigem: chamadoFront.setorOrigem,
            setorDestino: chamadoFront.setorDestino,
            solicitanteNome: chamadoFront.solicitanteNome,
            prioridade: chamadoFront.prioridade,
            descricao: chamadoFront.descricao,
            resolucao: resolucaoTexto || chamadoFront.resolucao || ''
          });
          emailResponsaveisNotificado = !!mailResp.sent;
        }
      } catch (eMailRespErr) {
        console.error('[email responsaveis status]', eMailRespErr);
      }
    }

    return res.json({ chamado: chamadoFront, emailNotificado, emailResponsaveisNotificado });
  } catch (err) {
    console.error('[chamados patch]', err);
    return res.status(500).json({ error: 'Erro ao atualizar chamado.' });
  }
});

/** DELETE /api/chamados/:numero — exclusão lógica (somente administrador). */
router.delete('/:numero', requireAuth, async (req, res) => {
  if (!isAdminUser(req.user)) {
    return res.status(403).json({ error: 'Apenas administradores podem excluir chamados.' });
  }
  const numero = decodeURIComponent(req.params.numero || '');
  if (!numero) {
    return res.status(400).json({ error: 'Identificador do chamado inválido.' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const { rows } = await client.query(
      `
      SELECT
        c.id,
        c.numero,
        c.status,
        c.prioridade,
        c.descricao,
        c.prazo,
        c.data_abertura,
        c.tipo,
        c.anexos_json,
        c.resolucao_texto,
        c.usuario_abertura_id,
        c.setor_solicitante_id,
        c.setor_responsavel_id,
        u.nome AS solicitante_nome,
        u.email AS solicitante_email,
        s1.codigo AS setor_origem_codigo,
        s1.nome AS setor_origem_nome,
        s2.codigo AS setor_destino_codigo,
        s2.nome AS setor_destino_nome
      FROM chamados c
      LEFT JOIN usuarios u ON c.usuario_abertura_id = u.id
      JOIN setores s1 ON c.setor_solicitante_id = s1.id
      JOIN setores s2 ON c.setor_responsavel_id = s2.id
      WHERE c.numero = $1 AND c.excluido_em IS NULL
      FOR UPDATE OF c
      `,
      [numero]
    );
    if (!rows.length) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Chamado não encontrado.' });
    }
    const chamado = rows[0];
    const backupAntesExclusao = {
      numero: chamado.numero,
      status: chamado.status,
      prioridade: chamado.prioridade,
      tipo: chamado.tipo,
      descricao: chamado.descricao,
      prazo: chamado.prazo,
      data_abertura: chamado.data_abertura,
      anexos: chamado.anexos_json || [],
      resolucao: chamado.resolucao_texto || null,
      solicitante: {
        id: chamado.usuario_abertura_id || null,
        nome: chamado.solicitante_nome || null,
        email: chamado.solicitante_email || null,
      },
      setor_origem: {
        id: chamado.setor_solicitante_id,
        codigo: chamado.setor_origem_codigo,
        nome: chamado.setor_origem_nome,
      },
      setor_destino: {
        id: chamado.setor_responsavel_id,
        codigo: chamado.setor_destino_codigo,
        nome: chamado.setor_destino_nome,
      },
      excluido_por_admin_id: req.user.id,
    };

    await client.query(
      `
      INSERT INTO historico (chamado_id, usuario_id, tipo_alteracao, valor_anterior, valor_novo)
      VALUES ($1, $2, 'exclusao', $3, $4)
      `,
      [
        chamado.id,
        req.user.id,
        JSON.stringify(backupAntesExclusao),
        JSON.stringify({ excluido_em: new Date().toISOString() }),
      ]
    );

    await client.query(
      `UPDATE chamados SET excluido_em = CURRENT_TIMESTAMP, atualizado_em = CURRENT_TIMESTAMP WHERE id = $1`,
      [chamado.id]
    );

    await client.query('COMMIT');
    return res.json({ ok: true, chamado: numero, backupRegistrado: true });
  } catch (err) {
    try {
      await client.query('ROLLBACK');
    } catch (_rbErr) { /* noop */ }
    console.error('[chamados delete]', err);
    return res.status(500).json({ error: 'Erro ao excluir chamado.' });
  } finally {
    client.release();
  }
});

module.exports = router;

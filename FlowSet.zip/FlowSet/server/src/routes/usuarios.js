const express = require('express');
const bcrypt = require('bcryptjs');
const { pool } = require('../db');
const { requireAuth, requirePerfil } = require('../middleware/auth');

const router = express.Router();
const PERFIS_VALIDOS = ['solicitante', 'atendente', 'coordenador', 'administrador'];
const SALT_ROUNDS = 10;

function senhaAtendePolitica(senha) {
  const v = String(senha || '');
  return v.length >= 8 && /[A-Z]/.test(v) && /[a-z]/.test(v) && /\d/.test(v);
}

/** GET /api/usuarios — listagem de usuários (somente administrador). */
router.get('/', requireAuth, requirePerfil('administrador'), async (_req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT
         u.id,
         u.nome,
         u.email,
         u.perfil,
         u.ativo,
         u.setor_id,
         s.codigo AS setor_codigo,
         s.nome AS setor_nome,
         u.ultimo_acesso,
         u.criado_em
       FROM usuarios u
       LEFT JOIN setores s ON s.id = u.setor_id
       ORDER BY u.nome ASC`
    );
    return res.json({ usuarios: rows });
  } catch (err) {
    console.error('[usuarios list]', err);
    return res.status(500).json({ error: 'Erro ao listar usuários.' });
  }
});

/** GET /api/usuarios/auditoria — últimas alterações administrativas. */
router.get('/auditoria', requireAuth, requirePerfil('administrador'), async (req, res) => {
  try {
    const limitRaw = Number(req.query.limit || 50);
    const limit = Number.isInteger(limitRaw) ? Math.min(Math.max(limitRaw, 1), 200) : 50;
    const alvoIdRaw = req.query.usuario_id != null ? Number(req.query.usuario_id) : null;

    const params = [limit];
    let where = '';
    if (alvoIdRaw != null && Number.isInteger(alvoIdRaw) && alvoIdRaw > 0) {
      where = 'WHERE a.usuario_alvo_id = $2';
      params.push(alvoIdRaw);
    }

    const { rows } = await pool.query(
      `
      SELECT
        a.id,
        a.acao,
        a.detalhes_json,
        a.criado_em,
        a.usuario_admin_id,
        a.usuario_alvo_id,
        adm.nome AS admin_nome,
        adm.email AS admin_email,
        alvo.nome AS alvo_nome,
        alvo.email AS alvo_email
      FROM usuarios_auditoria a
      LEFT JOIN usuarios adm ON adm.id = a.usuario_admin_id
      LEFT JOIN usuarios alvo ON alvo.id = a.usuario_alvo_id
      ${where}
      ORDER BY a.criado_em DESC
      LIMIT $1
      `,
      params
    );
    return res.json({ auditoria: rows });
  } catch (err) {
    console.error('[usuarios auditoria]', err);
    return res.status(500).json({ error: 'Erro ao listar auditoria de usuários.' });
  }
});

/** PATCH /api/usuarios/:id — atualização administrativa de usuário. */
router.patch('/:id', requireAuth, requirePerfil('administrador'), async (req, res) => {
  try {
    const userId = Number(req.params.id);
    if (!Number.isInteger(userId) || userId <= 0) {
      return res.status(400).json({ error: 'ID de usuário inválido.' });
    }

    const { perfil, setor_id, ativo, senha_nova } = req.body || {};
    const updates = [];
    const values = [];
    let index = 1;
    const auditoriaEventos = [];

    const { rows: atuaisRows } = await pool.query(
      `SELECT id, nome, email, perfil, setor_id, ativo, senha_hash FROM usuarios WHERE id = $1`,
      [userId]
    );
    if (!atuaisRows.length) {
      return res.status(404).json({ error: 'Usuário não encontrado.' });
    }
    const atual = atuaisRows[0];

    if (perfil != null) {
      const perfilNorm = String(perfil).trim().toLowerCase();
      if (!PERFIS_VALIDOS.includes(perfilNorm)) {
        return res.status(400).json({
          error: 'Perfil inválido.',
          permitidos: PERFIS_VALIDOS,
        });
      }
      updates.push(`perfil = $${index++}`);
      values.push(perfilNorm);
      if (perfilNorm !== String(atual.perfil || '')) {
        auditoriaEventos.push({
          acao: 'alteracao_perfil',
          detalhes: {
            antes: atual.perfil || null,
            depois: perfilNorm
          }
        });
      }
    }

    if (setor_id != null) {
      const setorId = Number(setor_id);
      if (!Number.isInteger(setorId) || setorId <= 0) {
        return res.status(400).json({ error: 'Setor inválido.' });
      }
      const { rows: setorRows } = await pool.query(
        `SELECT id FROM setores WHERE id = $1 AND ativo = TRUE`,
        [setorId]
      );
      if (setorRows.length === 0) {
        return res.status(400).json({ error: 'Setor inexistente ou inativo.' });
      }
      updates.push(`setor_id = $${index++}`);
      values.push(setorId);
      if (Number(atual.setor_id || 0) !== setorId) {
        const { rows: setorAtualRows } = await pool.query(
          `SELECT id, nome, codigo FROM setores WHERE id = $1`,
          [setorId]
        );
        const setorNovo = setorAtualRows[0] || null;
        auditoriaEventos.push({
          acao: 'alteracao_setor',
          detalhes: {
            antes: atual.setor_id || null,
            depois: setorId,
            depois_nome: setorNovo ? setorNovo.nome : null,
            depois_codigo: setorNovo ? setorNovo.codigo : null
          }
        });
      }
    }

    if (ativo != null) {
      if (typeof ativo !== 'boolean') {
        return res.status(400).json({ error: 'O campo ativo deve ser booleano.' });
      }
      if (req.user.id === userId && ativo === false) {
        return res.status(400).json({ error: 'Você não pode inativar sua própria conta.' });
      }
      updates.push(`ativo = $${index++}`);
      values.push(ativo);
      if (Boolean(atual.ativo) !== Boolean(ativo)) {
        auditoriaEventos.push({
          acao: 'alteracao_status',
          detalhes: {
            antes: Boolean(atual.ativo),
            depois: Boolean(ativo)
          }
        });
      }
    }

    if (senha_nova != null) {
      const senhaNova = String(senha_nova).trim();
      if (!senhaNova) {
        return res.status(400).json({ error: 'Informe uma nova senha.' });
      }
      if (!senhaAtendePolitica(senhaNova)) {
        return res.status(400).json({
          error: 'A nova senha deve ter 8+ caracteres, letra maiúscula, minúscula e número.'
        });
      }
      const senhaIgualAtual = await bcrypt.compare(senhaNova, String(atual.senha_hash || ''));
      if (senhaIgualAtual) {
        return res.status(400).json({ error: 'A nova senha deve ser diferente da senha atual.' });
      }
      const hash = await bcrypt.hash(senhaNova, SALT_ROUNDS);
      updates.push(`senha_hash = $${index++}`);
      values.push(hash);
      auditoriaEventos.push({
        acao: 'reset_senha',
        detalhes: {
          reset_por_admin: true
        }
      });
    }

    if (!updates.length) {
      return res.status(400).json({
        error: 'Nenhum campo para atualizar. Envie perfil, setor_id, ativo e/ou senha_nova.',
      });
    }

    values.push(userId);
    const { rows } = await pool.query(
      `
      UPDATE usuarios
      SET ${updates.join(', ')}, atualizado_em = CURRENT_TIMESTAMP
      WHERE id = $${index}
      RETURNING id
      `,
      values
    );
    if (!rows.length) {
      return res.status(404).json({ error: 'Usuário não encontrado.' });
    }

    const { rows: fullRows } = await pool.query(
      `SELECT
         u.id,
         u.nome,
         u.email,
         u.perfil,
         u.ativo,
         u.setor_id,
         s.codigo AS setor_codigo,
         s.nome AS setor_nome,
         u.ultimo_acesso,
         u.criado_em
       FROM usuarios u
       LEFT JOIN setores s ON s.id = u.setor_id
       WHERE u.id = $1`,
      [userId]
    );

    for (const evt of auditoriaEventos) {
      await pool.query(
        `
        INSERT INTO usuarios_auditoria (usuario_admin_id, usuario_alvo_id, acao, detalhes_json)
        VALUES ($1, $2, $3, $4::jsonb)
        `,
        [req.user.id, userId, evt.acao, JSON.stringify(evt.detalhes || {})]
      );
    }

    return res.json({ usuario: fullRows[0] });
  } catch (err) {
    console.error('[usuarios patch]', err);
    return res.status(500).json({ error: 'Erro ao atualizar usuário.' });
  }
});

/** DELETE /api/usuarios/:id — exclusão administrativa de usuário. */
router.delete('/:id', requireAuth, requirePerfil('administrador'), async (req, res) => {
  const userId = Number(req.params.id);
  if (!Number.isInteger(userId) || userId <= 0) {
    return res.status(400).json({ error: 'ID de usuário inválido.' });
  }
  if (Number(req.user.id) === userId) {
    return res.status(400).json({ error: 'Você não pode excluir sua própria conta.' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const { rows: alvoRows } = await client.query(
      `SELECT id, nome, email, perfil, ativo FROM usuarios WHERE id = $1 FOR UPDATE`,
      [userId]
    );
    if (!alvoRows.length) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Usuário não encontrado.' });
    }
    const alvo = alvoRows[0];

    if (String(alvo.perfil || '').toLowerCase() === 'administrador') {
      const { rows: adminRows } = await client.query(
        `SELECT COUNT(*)::int AS total
         FROM usuarios
         WHERE perfil = 'administrador' AND ativo = TRUE AND id <> $1`,
        [userId]
      );
      const outrosAdminsAtivos = Number(adminRows[0] ? adminRows[0].total : 0);
      if (outrosAdminsAtivos <= 0) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'Não é possível excluir o último administrador ativo.' });
      }
    }

    await client.query(
      `
      INSERT INTO usuarios_auditoria (usuario_admin_id, usuario_alvo_id, acao, detalhes_json)
      VALUES ($1, $2, $3, $4::jsonb)
      `,
      [
        req.user.id,
        userId,
        'alteracao_status',
        JSON.stringify({
          exclusao: true,
          alvo_nome: alvo.nome || null,
          alvo_email: alvo.email || null,
          perfil: alvo.perfil || null,
          ativo: Boolean(alvo.ativo),
        }),
      ]
    );

    await client.query(`DELETE FROM usuarios WHERE id = $1`, [userId]);
    await client.query('COMMIT');
    return res.json({ ok: true, usuario_id: userId });
  } catch (err) {
    try {
      await client.query('ROLLBACK');
    } catch (_rbErr) { /* noop */ }
    console.error('[usuarios delete]', err);
    return res.status(500).json({ error: 'Erro ao excluir usuário.' });
  } finally {
    client.release();
  }
});

module.exports = router;

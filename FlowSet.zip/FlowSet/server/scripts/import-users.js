const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const SALT_ROUNDS = 10;
const PERFIS_VALIDOS = new Set(['solicitante', 'atendente', 'coordenador', 'administrador']);

function normalizarPerfil(perfil) {
  const valor = String(perfil || '').trim().toLowerCase();
  if (!PERFIS_VALIDOS.has(valor)) {
    throw new Error(
      `Perfil inválido "${perfil}". Use: solicitante, atendente, coordenador ou administrador.`
    );
  }
  return valor;
}

function normalizarEmail(email) {
  return String(email || '').trim().toLowerCase();
}

function validarRegistro(item, idx) {
  if (!item || typeof item !== 'object') {
    throw new Error(`Registro ${idx + 1}: formato inválido.`);
  }
  if (!item.nome || !String(item.nome).trim()) {
    throw new Error(`Registro ${idx + 1}: nome é obrigatório.`);
  }
  if (!item.email || !String(item.email).trim()) {
    throw new Error(`Registro ${idx + 1}: e-mail é obrigatório.`);
  }
  if (!item.senha || String(item.senha).length < 6) {
    throw new Error(`Registro ${idx + 1}: senha deve ter no mínimo 6 caracteres.`);
  }
  normalizarPerfil(item.perfil || 'solicitante');
}

async function upsertUsuario(client, item) {
  const nome = String(item.nome).trim();
  const email = normalizarEmail(item.email);
  const senhaHash = await bcrypt.hash(String(item.senha), SALT_ROUNDS);
  const perfil = normalizarPerfil(item.perfil || 'solicitante');
  const ativo = item.ativo === false ? false : true;

  await client.query(
    `INSERT INTO usuarios (nome, email, senha_hash, perfil, ativo)
     VALUES ($1, $2, $3, $4, $5)
     ON CONFLICT (email)
     DO UPDATE SET
       nome = EXCLUDED.nome,
       senha_hash = EXCLUDED.senha_hash,
       perfil = EXCLUDED.perfil,
       ativo = EXCLUDED.ativo,
       atualizado_em = CURRENT_TIMESTAMP`,
    [nome, email, senhaHash, perfil, ativo]
  );
}

async function main() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error('DATABASE_URL não configurada no arquivo .env');
  }

  const fileArg = process.argv[2] || 'users.json';
  const inputPath = path.isAbsolute(fileArg) ? fileArg : path.join(__dirname, '..', fileArg);

  if (!fs.existsSync(inputPath)) {
    throw new Error(
      `Arquivo de usuários não encontrado em "${inputPath}". Crie com base em "users.exemplo.json".`
    );
  }

  const raw = fs.readFileSync(inputPath, 'utf8');
  const data = JSON.parse(raw);
  if (!Array.isArray(data) || data.length === 0) {
    throw new Error('O JSON deve ser um array com ao menos 1 usuário.');
  }
  data.forEach((item, idx) => validarRegistro(item, idx));

  const pool = new Pool({ connectionString });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    for (const item of data) {
      await upsertUsuario(client, item);
    }
    await client.query('COMMIT');
    console.log(`Importação concluída: ${data.length} usuário(s) processado(s).`);
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((err) => {
  console.error('[import-users] Falha:', err.message);
  process.exit(1);
});

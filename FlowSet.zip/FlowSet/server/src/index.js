const express = require('express');
const cors = require('cors');
const { testConnection } = require('./db');
const authRoutes = require('./routes/auth');
const setoresRoutes = require('./routes/setores');
const chamadosRoutes = require('./routes/chamados');
const dashboardRoutes = require('./routes/dashboard');
const usuariosRoutes = require('./routes/usuarios');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(
  cors({
    origin: true,
    credentials: true,
  })
);
app.use(express.json());

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'flowset-api' });
});

app.get('/api/health/db', async (_req, res) => {
  const result = await testConnection();
  if (result.ok) {
    return res.json({
      ok: true,
      database: 'connected',
      serverTime: result.now,
    });
  }
  return res.status(503).json({
    ok: false,
    database: 'disconnected',
    error: result.error,
  });
});

app.use('/api', authRoutes);
app.use('/api/setores', setoresRoutes);
app.use('/api/chamados', chamadosRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/usuarios', usuariosRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Erro interno do servidor.' });
});

app.listen(PORT, () => {
  console.log(`FlowSet API — http://localhost:${PORT}`);
  console.log('Rotas: POST /api/registro | POST /api/login | GET /api/me');
  console.log('        GET /api/setores | GET/POST/PATCH /api/chamados | GET /api/dashboard/metricas');
  console.log('        GET /api/usuarios (admin) | GET /api/health/db');
});

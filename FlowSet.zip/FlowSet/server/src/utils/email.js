const nodemailer = require('nodemailer');

function hasSmtpConfig() {
  return !!(process.env.SMTP_HOST && process.env.SMTP_PORT && process.env.SMTP_USER && process.env.SMTP_PASS);
}

function createTransporter() {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE || '').toLowerCase() === 'true',
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });
}

function normalizeRecipients(to) {
  if (Array.isArray(to)) {
    return to
      .map((item) => String(item || '').trim())
      .filter(Boolean);
  }
  const single = String(to || '').trim();
  return single ? [single] : [];
}

async function sendChamadoStatusEmail(params) {
  const recipients = normalizeRecipients(params && params.to);
  if (!recipients.length) return { sent: false, reason: 'destinatario-ausente' };
  if (!hasSmtpConfig()) {
    console.warn('[email] SMTP não configurado. E-mail não enviado.');
    return { sent: false, reason: 'smtp-nao-configurado' };
  }

  const status = String((params && params.status) || '').trim() || 'atualizado';
  const from = process.env.SMTP_FROM || process.env.SMTP_USER;
  const assunto = `FlowSet - Chamado ${params.numero} ${status}`;
  const texto = [
    'Olá,',
    '',
    `O chamado ${params.numero} está com status "${status}".`,
    `Setor solicitante: ${params.setorOrigem || '-'}`,
    `Setor responsável: ${params.setorDestino || '-'}`,
    `Solicitante: ${params.solicitanteNome || '-'}`,
    `Prioridade: ${params.prioridade || '-'}`,
    '',
    'Descrição:',
    params.descricao || '-',
    '',
    status.toLowerCase() === 'finalizado'
      ? 'Resolução:'
      : 'Observação:',
    status.toLowerCase() === 'finalizado'
      ? (params.resolucao || '-')
      : 'Acompanhe o chamado no FlowSet para mais detalhes.',
    '',
    'Equipe FlowSet'
  ].join('\n');

  const transporter = createTransporter();
  await transporter.sendMail({
    from,
    to: recipients.join(', '),
    subject: assunto,
    text: texto,
  });

  return { sent: true, recipients: recipients.length };
}

/** Confirma ao solicitante que o chamado foi registrado (abertura). */
async function sendChamadoCriadoSolicitanteEmail(params) {
  const recipients = normalizeRecipients(params && params.to);
  if (!recipients.length) return { sent: false, reason: 'destinatario-ausente' };
  if (!hasSmtpConfig()) {
    console.warn('[email] SMTP não configurado. E-mail não enviado.');
    return { sent: false, reason: 'smtp-nao-configurado' };
  }

  const from = process.env.SMTP_FROM || process.env.SMTP_USER;
  const numero = String((params && params.numero) || '').trim();
  const assunto = `FlowSet - Chamado ${numero} criado`;
  const nome = (params && params.nome) ? String(params.nome).trim() : '';
  const texto = [
    nome ? `Olá ${nome},` : 'Olá,',
    '',
    `Seu chamado ${numero} foi criado com sucesso e já está registrado no sistema com status "Aberto".`,
    `Setor solicitante: ${params.setorOrigem || '-'}`,
    `Setor responsável pelo atendimento: ${params.setorDestino || '-'}`,
    `Tipo: ${params.tipo || '-'}`,
    `Prioridade: ${params.prioridade || '-'}`,
    params.prazo && String(params.prazo).trim() && String(params.prazo).trim() !== '-'
      ? `Prazo desejado: ${params.prazo}`
      : null,
    '',
    'Descrição informada:',
    params.descricao || '-',
    '',
    'Você receberá outro e-mail quando o chamado for finalizado, com a descrição da resolução.',
    'Acompanhe o andamento pelo FlowSet.',
    '',
    'Equipe FlowSet',
  ]
    .filter((line) => line != null)
    .join('\n');

  const transporter = createTransporter();
  await transporter.sendMail({
    from,
    to: recipients.join(', '),
    subject: assunto,
    text: texto,
  });

  return { sent: true, recipients: recipients.length };
}

async function sendResolucaoEmail(params) {
  const recipients = normalizeRecipients(params && params.to);
  if (!recipients.length) return { sent: false, reason: 'destinatario-ausente' };
  if (!hasSmtpConfig()) {
    console.warn('[email] SMTP não configurado. E-mail não enviado.');
    return { sent: false, reason: 'smtp-nao-configurado' };
  }

  const transporter = createTransporter();

  const from = process.env.SMTP_FROM || process.env.SMTP_USER;
  const assunto = `FlowSet - Chamado ${params.numero} finalizado`;
  const texto = [
    `Olá ${params.nome || ''},`,
    '',
    `Seu chamado ${params.numero} foi finalizado.`,
    `Setor responsável: ${params.setorDestino || '-'}`,
    '',
    'Descrição da resolução:',
    params.resolucao || '-',
    '',
    'Equipe FlowSet'
  ].join('\n');

  await transporter.sendMail({
    from,
    to: recipients.join(', '),
    subject: assunto,
    text: texto,
  });

  return { sent: true, recipients: recipients.length };
}

module.exports = {
  hasSmtpConfig,
  sendResolucaoEmail,
  sendChamadoStatusEmail,
  sendChamadoCriadoSolicitanteEmail,
};

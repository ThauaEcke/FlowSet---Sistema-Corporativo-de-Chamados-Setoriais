const path = require('path');
const express = require('express');
const cors = require('cors');
const { hasSmtpConfig } = require('./utils/email');
const { testConnection } = require('./db');
const authRoutes = require('./routes/auth');
const setoresRoutes = require('./routes/setores');
const chamadosRoutes = require('./routes/chamados');
const dashboardRoutes = require('./routes/dashboard');
const usuariosRoutes = require('./routes/usuarios');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(
  cors({
    origin: true,
    credentials: true,
  })
);
app.use(express.json({ limit: '25mb' }));

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'flowset-api' });
});

app.get('/api/health/db', async (_req, res) => {
  const result = await testConnection();
  if (result.ok) {
    return res.json({
      ok: true,
      database: 'connected',
      serverTime: result.now,
    });
  }
  return res.status(503).json({
    ok: false,
    database: 'disconnected',
    error: result.error,
  });
});

app.use('/api', authRoutes);
app.use('/api/setores', setoresRoutes);
app.use('/api/chamados', chamadosRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/usuarios', usuariosRoutes);

/** Front estático (mesma origem que a API — evita bloqueio típico de file:// → localhost). */
const WEB_ROOT = path.join(__dirname, '..', '..');
function isForbiddenStaticPath(reqPath) {
  const norm = String(reqPath || '').replace(/\\/g, '/').toLowerCase();
  if (norm.includes('.env')) return true;
  const parts = norm.split('/').filter(Boolean);
  if (parts[0] === 'server' || parts[0] === 'node_modules') return true;
  if (parts.includes('node_modules')) return true;
  return false;
}
app.use((req, res, next) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') return next();
  if (isForbiddenStaticPath(req.path)) return res.status(404).end();
  return next();
});
app.use(express.static(WEB_ROOT, { index: 'index.html', dotfiles: 'deny' }));

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Erro interno do servidor.' });
});

const server = app.listen(PORT);

server.on('error', (err) => {
  if (err && err.code === 'EADDRINUSE') {
    console.error(
      `[FlowSet API] Porta ${PORT} já em uso. Feche o outro terminal que rodou "npm start" ou defina outra PORT no .env.`
    );
  } else {
    console.error(err);
  }
  process.exit(1);
});

server.once('listening', () => {
  console.log(`FlowSet API — http://localhost:${PORT}`);
  console.log(`Front (recomendado, mesma origem): http://localhost:${PORT}/login.html`);
  console.log(
    `[email] SMTP ${hasSmtpConfig() ? 'configurado (envio na abertura/atualização de chamados habilitado)' : 'não configurado — defina SMTP_* em server/.env'}`
  );
  console.log('Rotas: POST /api/registro | POST /api/login | GET /api/me');
  console.log('        GET /api/setores | GET/POST/PATCH /api/chamados | GET /api/dashboard/metricas');
  console.log('        GET /api/usuarios (admin) | GET /api/health/db');
});

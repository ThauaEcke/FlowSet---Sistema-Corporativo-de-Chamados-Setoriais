/* Configuração do frontend FlowSet
 * URL da API em ambiente local (escolha um dos jeitos):
 * - URL completa antes deste script: window.FLOWSET_API_ROOT = 'http://192.168.0.10:3000';
 * - Ou no console (persiste): localStorage.setItem('flowset_api_root', 'http://192.168.0.10:3000');
 * Só porta (mesmo PC que o navegador): localStorage.setItem('flowset_api_port', '3001');
 */
(function() {
  const PROD_API_ROOT = 'https://flowset-api.Unimed.com.br';

  function normalizeApiRoot(url) {
    if (!url || typeof url !== 'string') return null;
    var t = url.trim().replace(/\/$/, '');
    if (/^https?:\/\//i.test(t)) return t;
    return null;
  }

  /** URL base da API definida manualmente (prioridade sobre host:porta automático). */
  function resolvePresetApiRoot() {
    var fromWin = normalizeApiRoot(window.FLOWSET_API_ROOT);
    if (fromWin) return fromWin;
    try {
      var stored = localStorage.getItem('flowset_api_root');
      return normalizeApiRoot(stored);
    } catch (_e) {
      return null;
    }
  }

  function resolveLocalApiPort() {
    var fromWin = window.FLOWSET_API_PORT;
    if (fromWin !== undefined && fromWin !== null && fromWin !== '') {
      var n = parseInt(String(fromWin), 10);
      if (!isNaN(n) && n >= 1 && n <= 65535) return n;
    }
    try {
      var stored = localStorage.getItem('flowset_api_port');
      if (stored) {
        var ns = parseInt(String(stored), 10);
        if (!isNaN(ns) && ns >= 1 && ns <= 65535) return ns;
      }
    } catch (_e) { /* modo privado etc. */ }
    return 3000;
  }
  const host = (window.location.hostname || '').toLowerCase();
  const isIpv4 = /^\d{1,3}(\.\d{1,3}){3}$/.test(host);
  const isPrivateIpv4 = isIpv4 && (
    host.startsWith('10.') ||
    host.startsWith('127.') ||
    host.startsWith('192.168.') ||
    /^172\.(1[6-9]|2\d|3[0-1])\./.test(host)
  );
  const isHostnameIntranet = !!host && !host.includes('.') && host !== 'localhost';
  const isLocal =
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '::1' ||
    host === '' ||
    host.endsWith('.local') ||
    isPrivateIpv4 ||
    isHostnameIntranet;

  const presetApiRoot = resolvePresetApiRoot();

  const localApiHost = host === '::1' ? '[::1]' : (host || 'localhost');
  const localApiPort = resolveLocalApiPort();
  const localApiRoot = presetApiRoot || ('http://' + localApiHost + ':' + localApiPort);
  window.FLOWSET_API_ROOT = isLocal ? localApiRoot : PROD_API_ROOT;
  window.FLOWSET_API_PORT = presetApiRoot ? null : localApiPort;
  window.FLOWSET_STRICT_API = true;
})();

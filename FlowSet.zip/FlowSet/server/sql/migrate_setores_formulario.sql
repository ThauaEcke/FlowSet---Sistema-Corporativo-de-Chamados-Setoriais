-- Alinha setores com o formulário abrir-chamado.html (códigos estáveis).
-- Idempotente: pode rodar várias vezes.
INSERT INTO setores (codigo, nome) VALUES
    ('administrativo-financeiro', 'Administrativo / financeiro'),
    ('atendimento', 'Atendimento'),
    ('autorizacoes', 'Autorizações'),
    ('comercial', 'Comercial'),
    ('financeiro', 'Financeiro'),
    ('marketing', 'Marketing'),
    ('medicina-preventiva', 'Medicina Preventiva'),
    ('operacoes', 'Operações'),
    ('rh', 'Recursos Humanos'),
    ('saude-ocupacional', 'Saúde Ocupacional'),
    ('ser-cadia', 'SER CADIA'),
    ('ti', 'TI / Tecnologia da Informação')
ON CONFLICT (codigo) DO UPDATE SET nome = EXCLUDED.nome, ativo = TRUE;

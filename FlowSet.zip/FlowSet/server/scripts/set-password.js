const path = require('path');
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');

require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const email = process.argv[2];
const senha = process.argv[3];

if (!email || !senha) {
  console.error('Uso: node scripts/set-password.js <email> <senha>');
  process.exit(1);
}

async function main() {
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL não configurada no .env');
  }
  const hash = await bcrypt.hash(String(senha), 10);
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const { rowCount, rows } = await pool.query(
    'UPDATE usuarios SET senha_hash = $1 WHERE email = $2 RETURNING id, nome, email',
    [hash, String(email).trim().toLowerCase()]
  );
  await pool.end();
  if (rowCount === 0) {
    throw new Error('Usuário não encontrado: ' + email);
  }
  console.log('Senha atualizada:', rows[0].email, '(' + rows[0].nome + ')');
}

main().catch((err) => {
  console.error('[set-password]', err.message);
  process.exit(1);
});

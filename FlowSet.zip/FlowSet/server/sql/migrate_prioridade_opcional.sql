-- Permite abrir chamado sem prioridade (NULL no banco).
ALTER TABLE chamados DROP CONSTRAINT IF EXISTS chk_chamados_prioridade;
ALTER TABLE chamados ALTER COLUMN prioridade DROP NOT NULL;
ALTER TABLE chamados ADD CONSTRAINT chk_chamados_prioridade CHECK (
  prioridade IS NULL OR prioridade IN ('Baixa', 'Média', 'Alta', 'Crítica')
);

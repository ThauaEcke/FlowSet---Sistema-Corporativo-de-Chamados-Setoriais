# Pontos importantes para o Projeto Escrito — FlowSet

Este documento lista os tópicos mais relevantes para incluir na documentação escrita do projeto (relatório, memorial ou apresentação).

---

## 1. Introdução e contextualização

- **Objetivo do sistema**: FlowSet é um sistema corporativo de chamados setoriais, desenvolvido para centralizar a comunicação entre setores da Unimed.
- **Público-alvo**: Cooperativa Unimed, com foco na Unimed Alto Uruguai e integração ao SER CADIA (Centro de Atendimento ao Desenvolvimento da Infância e Adolescência).
- **Problema que resolve**: Organizar solicitações entre setores, com rastreabilidade, prazos e histórico completo de cada chamado.

---

## 2. Tecnologias utilizadas

| Tecnologia | Função |
|------------|--------|
| **HTML5** | Estrutura das páginas e semântica |
| **CSS3** | Estilização, layout responsivo, animações e variáveis CSS |
| **JavaScript** | Interatividade, validação, persistência com localStorage |
| **localStorage** | Armazenamento local dos dados (protótipo) |

---

## 3. Funcionalidades implementadas

- **Login e registro de usuários**: Autenticação simulada com armazenamento local.
- **Abertura de chamados**: Formulário com setor solicitante, setor responsável, tipo, prioridade, descrição e prazo.
- **Listagem de chamados**: Tabela dinâmica com dados do localStorage.
- **Detalhes do chamado**: Visualização completa ao clicar no ID (parâmetro na URL).
- **Dashboard**: Métricas em tempo real (abertos, em atendimento, finalizados).
- **Toggle de senha**: Mostrar/ocultar senha nos formulários de login e registro.
- **Validação de confirmação de senha**: Impede registro com senhas diferentes.

---

## 4. Setores do sistema

1. Administrativo / financeiro  
2. Recursos Humanos  
3. TI / Tecnologia da Informação  
4. Operações  
5. Comercial  
6. Atendimento  
7. **SER CADIA** — Centro de Atendimento ao Desenvolvimento da Infância e Adolescência  

---

## 5. Fluxo do sistema

1. **Acesso e autenticação** — Login com e-mail e senha  
2. **Abertura do chamado** — Preenchimento do formulário  
3. **Registro** — Chamado salvo com status "Aberto"  
4. **Assunção e atendimento** — Status "Em atendimento"  
5. **Acompanhamento** — Listagem e detalhes  
6. **Conclusão** — Status "Finalizado"  

---

## 6. Estrutura de arquivos

```
FlowSet/
├── index.html          # Página inicial
├── login.html          # Tela de login
├── registro.html       # Cadastro de usuário
├── dashboard.html      # Painel com métricas
├── abrir-chamado.html  # Formulário de abertura
├── listagem-chamados.html
├── detalhes-chamado.html
├── fluxo.html          # Fluxo do sistema
├── ser-cadia.html      # Página do SER CADIA
├── banco-dados.html    # Estrutura conceitual
├── styles.css          # Estilos globais
├── app.js              # Lógica e interações
├── assets/             # Imagens (logo)
├── RECOMENDACAO-BANCO-DADOS.md
└── PONTOS-PROJETO-ESCRITO.md (este arquivo)
```

---

## 7. Persistência de dados (protótipo)

- **localStorage**: Usado para simular banco de dados no navegador.
- **Chaves**: `flowset_usuario`, `flowset_chamados`, `flowset_proximo_id`.
- **Limitação**: Dados ficam por máquina; não há sincronização entre usuários.
- **Para produção**: Integrar com backend (Node.js, PHP) e banco de dados (PostgreSQL, MySQL).

---

## 8. Banco de dados recomendado

- **PostgreSQL** como banco principal.
- **Alternativa**: MySQL/MariaDB (comum em servidores com Apache/PHP).
- Schema completo e exemplos de API em `RECOMENDACAO-BANCO-DADOS.md`.

---

## 9. Implantação no servidor da Unimed

- **Ambiente**: Servidor local no prédio, com rede interna.
- **Requisitos mínimos**: Servidor web (Apache, IIS ou Nginx) para servir os arquivos HTML/CSS/JS.
- **Para dados centralizados**: Instalar PostgreSQL ou MySQL e criar backend (API).
- **Acesso**: Máquinas locais acessam via endereço do servidor (ex.: `http://servidor-unimed/FlowSet/`).

---

## 10. Considerações de segurança (para produção)

- Usar **HTTPS** em produção.
- **Hash de senha** (bcrypt) no backend; nunca armazenar senha em texto puro.
- **Autenticação** com tokens (JWT) ou sessões no servidor.
- **Validação** de dados no backend, não apenas no frontend.

---

## 11. Conclusão sugerida para o projeto escrito

O FlowSet foi desenvolvido como protótipo funcional de um sistema de chamados setoriais, utilizando tecnologias web padrão (HTML, CSS e JavaScript). O sistema atende aos requisitos de registro, listagem e acompanhamento de chamados entre os setores da Unimed, incluindo o SER CADIA. A persistência atual via localStorage permite demonstração e testes locais; para uso em produção, recomenda-se a integração com backend e banco de dados, conforme documentado em `RECOMENDACAO-BANCO-DADOS.md`. O projeto está preparado para implantação no servidor local da Unimed, com possibilidade de evolução para uma solução completa com dados centralizados.

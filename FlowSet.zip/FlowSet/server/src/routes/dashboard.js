const express = require('express');
const { pool } = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

function isAdminUser(user) {
  return String((user && user.perfil) || '').trim().toLowerCase() === 'administrador';
}

/** GET /api/dashboard/metricas — contagens por status (requer login). */
router.get('/metricas', requireAuth, async (req, res) => {
  try {
    const params = [];
    let filtroEscopo = '';
    if (!isAdminUser(req.user)) {
      filtroEscopo = 'AND (usuario_abertura_id = $1 OR ($2 IS NOT NULL AND setor_responsavel_id = $2))';
      params.push(req.user.id, req.user.setor_id || null);
    }
    const { rows } = await pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE status = 'Aberto') AS abertos,
        COUNT(*) FILTER (WHERE status = 'Em atendimento') AS em_atendimento,
        COUNT(*) FILTER (WHERE status = 'Finalizado') AS finalizados
      FROM chamados
      WHERE excluido_em IS NULL
      ${filtroEscopo}
    `, params);
    const r = rows[0] || {};
    return res.json({
      abertos: parseInt(r.abertos, 10) || 0,
      emAtendimento: parseInt(r.em_atendimento, 10) || 0,
      finalizados: parseInt(r.finalizados, 10) || 0,
    });
  } catch (err) {
    console.error('[dashboard metricas]', err);
    return res.status(500).json({ error: 'Erro ao carregar métricas.' });
  }
});

module.exports = router;

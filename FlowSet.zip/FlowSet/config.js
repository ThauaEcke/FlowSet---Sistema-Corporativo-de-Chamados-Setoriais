/* Configuração do frontend FlowSet */
(function() {
  const PROD_API_ROOT = 'https://flowset-api.suaempresa.com.br';
  const host = (window.location.hostname || '').toLowerCase();
  const isLocal =
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '::1' ||
    host === '';

  window.FLOWSET_API_ROOT = isLocal ? 'http://localhost:3000' : PROD_API_ROOT;
  window.FLOWSET_STRICT_API = true;
})();

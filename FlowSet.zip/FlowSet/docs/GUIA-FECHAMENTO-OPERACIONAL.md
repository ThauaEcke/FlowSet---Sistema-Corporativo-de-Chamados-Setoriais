# Guia operacional — fechamento FlowSet

Documento de apoio ao [CHECKLIST-FECHAMENTO.md](../CHECKLIST-FECHAMENTO.md): rotação de segredos, deploy, backup/restauração e testes manuais no front.

---

## 1. Rotação de credenciais (SMTP, banco, JWT)

Execute sempre que houver suspeita de vazamento (commit acidental, print, chat, repositório público).

1. **`JWT_SECRET` (servidor)**  
   - Gere uma string longa e aleatória (ex.: PowerShell: `[Convert]::ToBase64String((1..48 | ForEach-Object { Get-Random -Maximum 256 }) -as [byte[]])'` ou `openssl rand -base64 48`).  
   - Atualize em `server/.env`.  
   - **Efeito:** todos os tokens JWT antigos deixam de ser válidos; usuários precisam fazer login novamente.

2. **PostgreSQL (`DATABASE_URL`)**  
   - Altere a senha do usuário no PostgreSQL (`ALTER USER ... PASSWORD '...';`).  
   - Atualize a URL em `server/.env`.  
   - Reinicie a API.

3. **Gmail / SMTP (`SMTP_PASS`)**  
   - Revogue a senha de app antiga no Google Conta → Segurança → Senhas de app.  
   - Crie uma nova senha de app e coloque em `SMTP_PASS` no `server/.env`.  
   - Confirme envio com um fluxo que dispare e-mail (ex.: finalizar chamado).

4. **Nunca** commite `server/.env` (já está em `server/.gitignore`). Use apenas `server/.env.example` como modelo.

---

## 2. Estratégia de deploy em produção (resumo)

Defina com a equipe de infraestrutura; pontos mínimos:

| Tema | Sugestão |
|------|----------|
| Processo Node | **PM2**, **systemd** ou container (Docker) com reinício automático |
| Proxy reverso | **Nginx** ou **Caddy** na frente da API (porta interna 3000) |
| HTTPS | Certificado gerenciado (Let's Encrypt) no proxy |
| Domínio | DNS apontando para o servidor; CORS/origin conforme URL do front |
| Front estático | Servir HTML/JS/CSS pelo mesmo domínio ou CDN; ajustar `API_BASE` em `config.js` |
| Variáveis | `DATABASE_URL`, `JWT_SECRET`, SMTP apenas no servidor (secrets do ambiente) |
| Logs | Redirecionar stdout da API + rotação de arquivos de log |

Backup e contingência ficam na seção seguinte.

---

## 3. Backup e restauração do banco (contingência)

**Backup lógico (recomendado, portátil):**

```bash
pg_dump --format=custom --file=flowset_backup_YYYYMMDD.dump "SUA_DATABASE_URL"
```

Ou com URL em variável (PowerShell):

```powershell
$env:PGPASSWORD = "senha_do_usuario_pg"
pg_dump -h localhost -U postgres -d nome_do_banco -F c -f flowset_backup.dump
```

**Restaurar em banco vazio (ex.: após incidente):**

```bash
pg_restore --clean --if-exists --dbname="postgresql://..." flowset_backup_YYYYMMDD.dump
```

Ajuste usuário/host conforme o ambiente. Em produção, combine com:

- cópias fora do servidor (objeto storage ou outra máquina);
- teste periódico de **restauração em ambiente de homologação**;
- RPO/RTO alinhados com a Unimed (quanto tempo de dados aceitável perder / quanto tempo para voltar).

**Contingência se a API cair:** manter contato do DBA/hosting; documentar onde está o último dump válido e o procedimento de `pg_restore` acima.

---

## 4. Bateria de testes manuais no front (perfis)

Execute logado com contas reais ou de teste. Anote data e resultado.

### Perfil solicitante (abre chamado)

- [ ] Login com usuário de um setor não administrador.  
- [ ] Abrir chamado: setores diferentes, tipo, descrição válida, prioridade opcional vazia e preenchida.  
- [ ] Anexo opcional (arquivo pequeno).  
- [ ] Listagem mostra apenas chamados do escopo esperado (regra da API).  
- [ ] Abrir detalhe de um chamado que você abriu.

### Perfil atendente (setor responsável)

- [ ] Login com usuário do setor destino de um chamado aberto.  
- [ ] Listagem inclui chamados em que o setor é responsável.  
- [ ] Alterar status / finalizar com resolução (se aplicável ao fluxo).  
- [ ] Verificar e-mail de notificação se SMTP configurado.

### Perfil administrador

- [ ] Login como admin.  
- [ ] Listagem / dashboard com visão ampla (conforme implementação).  
- [ ] Operações administrativas que o projeto expuser (usuários, etc.).

### Regressão rápida

- [ ] Logout e login.  
- [ ] Página de abrir chamado com setores carregados da API.  
- [ ] Mensagens de erro claras com API desligada (se `STRICT_API` ativo).

---

*Última atualização do guia: alinhado ao checklist de fechamento do projeto FlowSet.*

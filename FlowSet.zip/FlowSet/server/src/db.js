const path = require('path');
const { Pool } = require('pg');
// Sempre server/.env, mesmo se node for iniciado fora da pasta server (evita SMTP “sumir” no app).
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  console.warn(
    '[db] DATABASE_URL não definida. Copie server/.env.example para server/.env e configure.'
  );
}

const pool = new Pool({
  connectionString,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

pool.on('error', (err) => {
  console.error('[db] Erro inesperado no pool:', err.message);
});

/**
 * Testa a conexão executando uma query simples.
 * @returns {Promise<{ ok: boolean, now?: string, error?: string }>}
 */
async function testConnection() {
  if (!connectionString) {
    return { ok: false, error: 'DATABASE_URL não configurada' };
  }
  const client = await pool.connect();
  try {
    const { rows } = await client.query('SELECT NOW() AS now');
    return { ok: true, now: rows[0].now.toISOString() };
  } catch (err) {
    return { ok: false, error: err.message };
  } finally {
    client.release();
  }
}

module.exports = { pool, testConnection };

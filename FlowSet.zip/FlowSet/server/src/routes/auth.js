const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { pool } = require('../db');
const { requireAuth, getJwtSecret } = require('../middleware/auth');

const router = express.Router();
const SALT_ROUNDS = 10;

async function resolveSetorId(setorId) {
  if (!setorId) return null;
  const parsed = Number(setorId);
  if (!Number.isInteger(parsed) || parsed <= 0) return null;
  const { rows } = await pool.query(
    `SELECT id FROM setores WHERE id = $1 AND ativo = TRUE`,
    [parsed]
  );
  return rows[0] ? rows[0].id : null;
}

function signToken(user) {
  return jwt.sign(
    { sub: user.id, email: user.email },
    getJwtSecret(),
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

/** POST /api/registro — cadastro público */
router.post('/registro', async (req, res) => {
  try {
    const { nome, email, senha, setor_id } = req.body || {};
    if (!nome || !email || !senha) {
      return res.status(400).json({ error: 'Informe nome, e-mail e senha.' });
    }
    if (String(senha).length < 6) {
      return res.status(400).json({ error: 'A senha deve ter pelo menos 6 caracteres.' });
    }
    const emailNorm = String(email).trim().toLowerCase();
    const hash = await bcrypt.hash(String(senha), SALT_ROUNDS);
    const setorId = await resolveSetorId(setor_id);
    if (!setorId) {
      return res.status(400).json({ error: 'Selecione um setor válido.' });
    }
    const { rows: countRows } = await pool.query(
      `SELECT COUNT(*)::int AS total FROM usuarios`
    );
    const totalUsuarios = Number(countRows[0] && countRows[0].total ? countRows[0].total : 0);
    const perfilRegistro = totalUsuarios === 0 ? 'administrador' : 'solicitante';
    const { rows } = await pool.query(
      `INSERT INTO usuarios (nome, email, senha_hash, setor_id, perfil)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, nome, email, perfil, setor_id, criado_em`,
      [String(nome).trim(), emailNorm, hash, setorId, perfilRegistro]
    );
    const uBase = rows[0];
    const { rows: setorRows } = await pool.query(
      `SELECT codigo, nome FROM setores WHERE id = $1`,
      [uBase.setor_id]
    );
    const setor = setorRows[0] || null;
    const token = signToken({ id: uBase.id, email: uBase.email });
    return res.status(201).json({
      token,
      usuario: {
        id: uBase.id,
        nome: uBase.nome,
        email: uBase.email,
        perfil: uBase.perfil,
        setor_id: uBase.setor_id,
        setor_codigo: setor ? setor.codigo : null,
        setor_nome: setor ? setor.nome : null,
      },
    });
  } catch (err) {
    if (err.code === '23505') {
      return res.status(409).json({ error: 'Este e-mail já está cadastrado.' });
    }
    console.error('[registro]', err);
    return res.status(500).json({ error: 'Erro ao registrar. Tente novamente.' });
  }
});

/** POST /api/login */
router.post('/login', async (req, res) => {
  try {
    const { email, senha } = req.body || {};
    if (!email || !senha) {
      return res.status(400).json({ error: 'Informe e-mail e senha.' });
    }
    const emailNorm = String(email).trim().toLowerCase();
    const { rows } = await pool.query(
      `SELECT
         u.id,
         u.nome,
         u.email,
         u.senha_hash,
         u.perfil,
         u.ativo,
         u.setor_id,
         s.codigo AS setor_codigo,
         s.nome AS setor_nome
       FROM usuarios u
       LEFT JOIN setores s ON s.id = u.setor_id
       WHERE u.email = $1`,
      [emailNorm]
    );
    if (rows.length === 0) {
      return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
    }
    const u = rows[0];
    if (u.ativo === false) {
      return res.status(403).json({ error: 'Usuário inativo.' });
    }
    const ok = await bcrypt.compare(String(senha), u.senha_hash);
    if (!ok) {
      return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
    }
    await pool.query(`UPDATE usuarios SET ultimo_acesso = CURRENT_TIMESTAMP WHERE id = $1`, [u.id]);
    const token = signToken({ id: u.id, email: u.email });
    return res.json({
      token,
      usuario: {
        id: u.id,
        nome: u.nome,
        email: u.email,
        perfil: u.perfil,
        setor_id: u.setor_id || null,
        setor_codigo: u.setor_codigo || null,
        setor_nome: u.setor_nome || null,
      },
    });
  } catch (err) {
    console.error('[login]', err);
    return res.status(500).json({ error: 'Erro ao entrar. Tente novamente.' });
  }
});

/** GET /api/me — usuário do token */
router.get('/me', requireAuth, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT
         u.id,
         u.nome,
         u.email,
         u.perfil,
         u.setor_id,
         s.codigo AS setor_codigo,
         s.nome AS setor_nome,
         u.criado_em
       FROM usuarios u
       LEFT JOIN setores s ON s.id = u.setor_id
       WHERE u.id = $1`,
      [req.user.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Usuário não encontrado.' });
    }
    const u = rows[0];
    return res.json({ usuario: u });
  } catch (err) {
    console.error('[me]', err);
    return res.status(500).json({ error: 'Erro ao carregar perfil.' });
  }
});

module.exports = router;

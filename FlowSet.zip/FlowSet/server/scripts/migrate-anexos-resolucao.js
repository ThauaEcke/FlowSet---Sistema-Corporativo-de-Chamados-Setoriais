const { Client } = require('pg');
require('dotenv').config();

async function main() {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error('DATABASE_URL não configurada em server/.env');
  }

  const client = new Client({ connectionString: databaseUrl });
  await client.connect();
  try {
    await client.query(`
      ALTER TABLE chamados
      ADD COLUMN IF NOT EXISTS anexos_json JSONB
    `);
    await client.query(`
      ALTER TABLE chamados
      ADD COLUMN IF NOT EXISTS resolucao_texto TEXT
    `);
    console.log('[migrate] Colunas anexos_json e resolucao_texto prontas.');
  } finally {
    await client.end();
  }
}

main().catch((err) => {
  console.error('[migrate] Erro:', err.message);
  process.exit(1);
});

const { Client } = require('pg');
require('dotenv').config();

async function main() {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error('DATABASE_URL não configurada em server/.env');
  }

  const client = new Client({ connectionString: databaseUrl });
  await client.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS usuarios_auditoria (
        id SERIAL PRIMARY KEY,
        usuario_admin_id INTEGER REFERENCES usuarios (id) ON DELETE SET NULL,
        usuario_alvo_id INTEGER REFERENCES usuarios (id) ON DELETE SET NULL,
        acao VARCHAR(40) NOT NULL,
        detalhes_json JSONB NOT NULL DEFAULT '{}'::jsonb,
        criado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
      )
    `);
    await client.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1
          FROM pg_constraint
          WHERE conname = 'chk_usuarios_auditoria_acao'
        ) THEN
          ALTER TABLE usuarios_auditoria
          ADD CONSTRAINT chk_usuarios_auditoria_acao CHECK (
            acao IN ('alteracao_perfil', 'alteracao_setor', 'alteracao_status', 'reset_senha')
          );
        END IF;
      END$$
    `);
    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_usuarios_auditoria_alvo
      ON usuarios_auditoria (usuario_alvo_id, criado_em DESC)
    `);
    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_usuarios_auditoria_admin
      ON usuarios_auditoria (usuario_admin_id, criado_em DESC)
    `);
    console.log('[migrate] Tabela usuarios_auditoria pronta.');
  } finally {
    await client.end();
  }
}

main().catch((err) => {
  console.error('[migrate] Erro:', err.message);
  process.exit(1);
});

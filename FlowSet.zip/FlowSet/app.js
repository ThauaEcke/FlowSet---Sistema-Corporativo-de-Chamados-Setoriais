/**
 * FlowSet - Interações, animações e funcionalidade
 * Usa localStorage para dados do app; sessão de login em sessionStorage (fecha a aba = novo login)
 * Para produção: integrar com backend e banco de dados
 */

(function() {
  'use strict';

  /* ========== CHAVES DO LOCALSTORAGE ==========
   * Define os nomes das chaves usadas para armazenar dados no navegador.
   * flowset_usuario: dados do usuário logado (sessionStorage — some ao fechar a aba)
   * flowset_chamados: lista de todos os chamados
   * flowset_proximo_id: próximo número de chamado (ex: 2025-0043)
   * Cada chamado pode ter solicitanteEmail (quem abriu o registro no protótipo).
   */
  const STORAGE_KEYS = {
    usuario: 'flowset_usuario',
    token: 'flowset_token',
    chamados: 'flowset_chamados',
    proximoId: 'flowset_proximo_id',
    draftAbertura: 'flowset_draft_abertura'
  };

  const API_ROOT = (window.FLOWSET_API_ROOT || 'http://localhost:3000').replace(/\/$/, '');
  const API_BASE = API_ROOT + '/api';
  const STRICT_API = !!window.FLOWSET_STRICT_API;

  function getAuthToken() {
    return localStorage.getItem(STORAGE_KEYS.token) || sessionStorage.getItem(STORAGE_KEYS.token) || null;
  }

  function salvarSessaoApi(token, usuario) {
    if (token) {
      localStorage.setItem(STORAGE_KEYS.token, token);
      sessionStorage.setItem(STORAGE_KEYS.token, token);
    }
    if (usuario) {
      sessionStorage.setItem(STORAGE_KEYS.usuario, JSON.stringify(usuario));
    }
  }

  async function apiRequest(path, options) {
    const opts = options || {};
    const headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
    const token = getAuthToken();
    if (token) headers.Authorization = 'Bearer ' + token;
    let response;
    try {
      response = await fetch(API_BASE + path, Object.assign({}, opts, { headers }));
    } catch (_networkErr) {
      const err = new Error('Falha de conexão com a API. Verifique se o backend está ativo.');
      err.status = 0;
      throw err;
    }
    let payload = null;
    try {
      payload = await response.json();
    } catch (_errJson) {
      payload = null;
    }
    if (!response.ok) {
      const msg = payload && payload.error ? payload.error : ('Erro HTTP ' + response.status);
      const err = new Error(msg);
      err.status = response.status;
      throw err;
    }
    return payload || {};
  }

  async function carregarSetoresAtivos() {
    const data = await apiRequest('/setores');
    if (!data || !Array.isArray(data.setores)) return [];
    return data.setores.filter(function(s) {
      return s && s.id && s.codigo && s.nome;
    });
  }

  function preencherSelectSetores(selectEl, setores, placeholder) {
    if (!selectEl) return;
    const ph = placeholder || 'Selecione o setor';
    selectEl.innerHTML = '';
    selectEl.insertAdjacentHTML('beforeend', '<option value="">' + ph + '</option>');
    setores.forEach(function(setor) {
      const option = document.createElement('option');
      option.value = String(setor.codigo);
      option.textContent = setor.nome;
      option.dataset.setorId = String(setor.id);
      option.dataset.setorCodigo = String(setor.codigo);
      selectEl.appendChild(option);
    });
  }

  function setFormFeedback(formEl, message, tipo) {
    if (!formEl) return;
    var cls = tipo === 'sucesso' ? 'mensagem-sucesso' : (tipo === 'alerta' ? 'mensagem-alerta' : 'mensagem-erro');
    var box = formEl.querySelector('.flowset-form-feedback');
    if (!box) {
      box = document.createElement('div');
      box.className = 'flowset-form-feedback';
      formEl.insertAdjacentElement('afterbegin', box);
    }
    box.className = 'flowset-form-feedback ' + cls;
    box.textContent = message;
  }

  function clearFormFeedback(formEl) {
    if (!formEl) return;
    var box = formEl.querySelector('.flowset-form-feedback');
    if (box) box.remove();
  }

  function setButtonLoading(buttonEl, isLoading, loadingLabel) {
    if (!buttonEl) return;
    if (isLoading) {
      if (!buttonEl.dataset.originalLabel) {
        buttonEl.dataset.originalLabel = buttonEl.innerHTML;
      }
      buttonEl.disabled = true;
      buttonEl.setAttribute('aria-busy', 'true');
      buttonEl.innerHTML = loadingLabel || 'Carregando...';
      return;
    }
    if (buttonEl.dataset.originalLabel) {
      buttonEl.innerHTML = buttonEl.dataset.originalLabel;
      delete buttonEl.dataset.originalLabel;
    }
    buttonEl.disabled = false;
    buttonEl.removeAttribute('aria-busy');
  }

  function isPastDateInputValue(dateValue) {
    if (!dateValue) return false;
    var selected = new Date(dateValue + 'T00:00:00');
    if (isNaN(selected.getTime())) return false;
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    return selected < today;
  }

  function padronizarPrioridade(valor) {
    var v = (valor || '').toString().trim().toLowerCase();
    if (v === 'baixa') return 'Baixa';
    if (v === 'media' || v === 'média') return 'Média';
    if (v === 'alta') return 'Alta';
    if (v === 'critica' || v === 'crítica') return 'Crítica';
    return valor || '-';
  }

  function normalizarTextoBase(valor) {
    return (valor || '')
      .toString()
      .trim()
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');
  }

  function padronizarStatus(valor) {
    var v = normalizarTextoBase(valor);
    if (!v) return 'Aberto';
    if (v.includes('finalizado')) return 'Finalizado';
    if (v.includes('atendimento')) return 'Em atendimento';
    if (v.includes('critico')) return 'Crítico';
    if (v.includes('aberto')) return 'Aberto';
    return valor || 'Aberto';
  }

  function showPageNotice(message, tipo) {
    var host = document.querySelector('.conteudo') || document.querySelector('.conteudo-narrow') || document.querySelector('main');
    if (!host) return;
    var id = 'flowset-page-notice';
    if (host.querySelector('#' + id)) return;
    var div = document.createElement('div');
    div.id = id;
    div.className = tipo === 'erro' ? 'mensagem-erro' : 'mensagem-alerta';
    div.textContent = message;
    host.insertAdjacentElement('afterbegin', div);
  }

  function showToastGlobal(message, tipo) {
    var toast = document.createElement('div');
    toast.className = 'resolver-toast flowset-toast-global';
    if (tipo === 'erro') toast.className += ' flowset-toast-global--erro';
    if (tipo === 'sucesso') toast.className += ' flowset-toast-global--sucesso';
    toast.setAttribute('role', 'status');
    toast.textContent = message;
    document.body.appendChild(toast);
    requestAnimationFrame(function() { toast.classList.add('resolver-toast--show'); });
    setTimeout(function() {
      toast.classList.remove('resolver-toast--show');
      setTimeout(function() { if (toast.parentNode) toast.remove(); }, 280);
    }, 3200);
  }

  function podeUsarFallbackLocal(apiErr) {
    if (STRICT_API) return false;
    if (!apiErr || typeof apiErr.status !== 'number') return true;
    return apiErr.status >= 500;
  }

  async function getChamadosPreferApi() {
    try {
      const data = await apiRequest('/chamados');
      if (data && Array.isArray(data.chamados)) return data.chamados;
    } catch (apiErr) {
      if (podeUsarFallbackLocal(apiErr)) {
        showPageNotice('API indisponível no momento. Exibindo dados locais.', 'alerta');
      } else {
        showPageNotice('Falha ao carregar chamados pela API.', 'erro');
        return [];
      }
    }
    return initChamados();
  }

  /* ========== MAPEAMENTO DE SETORES ==========
   * Relaciona o valor interno (código) com o rótulo exibido na interface.
   * Usado ao salvar e exibir chamados.
   */
  const SETORES_LABEL = {
    'administrativo-financeiro': 'Administrativo / financeiro',
    'rh': 'RH',
    'ti': 'TI',
    'operacoes': 'Operações',
    'comercial': 'Comercial',
    'atendimento': 'Atendimento',
    'ser-cadia': 'SER CADIA',
    'autorizacoes': 'Autorizações',
    'financeiro': 'Financeiro',
    'marketing': 'Marketing',
    'medicina-preventiva': 'Medicina Preventiva',
    'saude-ocupacional': 'Saúde Ocupacional'
  };

  /* ========== SOLICITANTES DINÂMICOS ==========
   * Remove a lista fixa de nomes e usa usuários cadastrados localmente
   * (flowset_usuarios) + usuário logado na sessão atual.
   */
  const STORAGE_LOCAL_USERS_KEY = 'flowset_usuarios';
  const SETORES_LABEL_NORMALIZADOS = Object.keys(SETORES_LABEL).reduce(function(acc, codigo) {
    const nome = SETORES_LABEL[codigo];
    acc[normalizarTextoBase(nome)] = codigo;
    return acc;
  }, {});

  function getUsuariosCadastroLocal() {
    try {
      const raw = localStorage.getItem(STORAGE_LOCAL_USERS_KEY);
      const lista = raw ? JSON.parse(raw) : [];
      return Array.isArray(lista) ? lista : [];
    } catch (_errUsuarios) {
      return [];
    }
  }

  function resolverSetorCodigoUsuario(usuario) {
    if (!usuario || typeof usuario !== 'object') return '';
    if (usuario.setor_codigo) return String(usuario.setor_codigo).trim().toLowerCase();
    const nomeSetor = normalizarTextoBase(usuario.setor_nome || '');
    return SETORES_LABEL_NORMALIZADOS[nomeSetor] || '';
  }

  function resolverNomeUsuario(usuario) {
    if (!usuario || typeof usuario !== 'object') return '';
    const nome = String(usuario.nome || '').trim();
    if (nome) return nome;
    const email = String(usuario.email || '').trim();
    if (!email) return '';
    return email.split('@')[0];
  }

  function listarColaboradoresPorSetor(setorCodigo) {
    const setor = String(setorCodigo || '').trim().toLowerCase();
    if (!setor) return [];

    const nomes = [];
    const nomesNormalizados = new Set();
    function addNome(nome) {
      const nomeFinal = String(nome || '').trim();
      const chave = normalizarTextoBase(nomeFinal);
      if (!nomeFinal || !chave || nomesNormalizados.has(chave)) return;
      nomesNormalizados.add(chave);
      nomes.push(nomeFinal);
    }

    getUsuariosCadastroLocal().forEach(function(usuario) {
      const setorUsuario = resolverSetorCodigoUsuario(usuario);
      if (setorUsuario !== setor) return;
      if (usuario.ativo === false) return;
      addNome(resolverNomeUsuario(usuario));
    });

    const usuarioSessao = getUsuarioSessaoAtual();
    if (usuarioSessao && resolverSetorCodigoUsuario(usuarioSessao) === setor) {
      addNome(resolverNomeUsuario(usuarioSessao));
    }

    nomes.sort(function(a, b) { return a.localeCompare(b, 'pt-BR'); });
    return nomes;
  }

  /* ========== CLASSES CSS PARA STATUS ==========
   * Mapeia o status do chamado para a classe CSS que define a cor do badge.
   */
  const STATUS_CLASS = {
    'aberto': 'status-aberto',
    'em atendimento': 'status-atendimento',
    'finalizado': 'status-finalizado',
    'critico': 'status-critico'
  };

  /* ========== CLASSES CSS PARA PRIORIDADE ========== */
  const PRIORIDADE_CLASS = {
    'baixa': 'prioridade-baixa',
    'media': 'prioridade-media',
    'alta': 'prioridade-alta',
    'critica': 'prioridade-alta'
  };

  /**
   * Retorna a lista de chamados armazenada no localStorage.
   * Se não houver dados, retorna array vazio.
   */
  function getChamados() {
    const dados = localStorage.getItem(STORAGE_KEYS.chamados);
    return dados ? JSON.parse(dados) : [];
  }

  /**
   * Retorna os chamados iniciais de demonstração.
   * Usados na primeira carga ou quando não há dados salvos.
   */
  function getChamadosIniciais() {
    return [
      { id: '2025-0042', setorOrigem: 'Marketing', setorDestino: 'TI', status: 'Em atendimento', prioridade: 'Alta', prazo: '05/03/2025', tipo: 'Suporte técnico', descricao: 'Solicitação de suporte para instalação e configuração de ferramentas de vendas.', tramitacao: [{ quando: '2025-02-28T17:30:00.000Z', texto: 'Chamado encaminhado ao setor TI.', porNome: 'Sistema' }] },
      { id: '2025-0041', setorOrigem: 'RH', setorDestino: 'Financeiro', status: 'Finalizado', prioridade: 'Média', prazo: '28/02/2025', tipo: 'Documentação', descricao: 'Solicitação de documentação.', tramitacao: [{ quando: '2025-02-28T10:00:00.000Z', texto: 'Solicitação finalizada e arquivada.', porNome: 'Sistema' }] },
      { id: '2025-0040', setorOrigem: 'Autorizações', setorDestino: 'Financeiro', status: 'Aberto', prioridade: 'Baixa', prazo: '10/03/2025', tipo: 'Aprovação', descricao: 'Solicitação de aprovação.', tramitacao: [{ quando: '2025-02-27T14:00:00.000Z', texto: 'Registro aberto para análise do setor Financeiro.', porNome: 'Sistema' }] },
      { id: '2025-0039', setorOrigem: 'SER CADIA', setorDestino: 'TI', status: 'Crítico', prioridade: 'Crítica', prazo: '01/03/2025', tipo: 'Suporte técnico', descricao: 'Urgência em suporte.', tramitacao: [{ quando: '2025-02-26T09:00:00.000Z', texto: 'Prioridade crítica atribuída pela equipe TI.', porNome: 'Sistema' }] },
      { id: '2025-0038', setorOrigem: 'Saúde Ocupacional', setorDestino: 'RH', status: 'Finalizado', prioridade: 'Média', prazo: '25/02/2025', tipo: 'Solicitação de informação', descricao: 'Informações para RH.', tramitacao: [{ quando: '2025-02-25T16:00:00.000Z', texto: 'Informações enviadas ao solicitante.', porNome: 'Sistema' }] },
      { id: '2025-0037', setorOrigem: 'Medicina Preventiva', setorDestino: 'Autorizações', status: 'Em atendimento', prioridade: 'Baixa', prazo: '08/03/2025', tipo: 'Ajuste de processo', descricao: 'Ajuste de processo operacional.', tramitacao: [{ quando: '2025-02-24T11:20:00.000Z', texto: 'Em análise pelo setor Autorizações.', porNome: 'Sistema' }] }
    ];
  }

  /**
   * Inicializa os chamados no localStorage.
   * Se não houver chamados, carrega os dados iniciais e salva.
   * Retorna a lista de chamados (inicializados ou existentes).
   */
  function initChamados() {
    let chamados = getChamados();
    if (chamados.length === 0) {
      chamados = getChamadosIniciais();
      localStorage.setItem(STORAGE_KEYS.chamados, JSON.stringify(chamados));
      localStorage.setItem(STORAGE_KEYS.proximoId, '2025-0043');
    }
    return chamados;
  }

  /**
   * Formata uma data no padrão brasileiro (DD/MM/AAAA).
   * @param {string} dataStr - Data no formato YYYY-MM-DD (input date)
   * @returns {string} Data formatada ou '-' se inválida
   */
  function formatarData(dataStr) {
    if (!dataStr) return '-';
    const d = new Date(dataStr + 'T12:00:00');
    return d.toLocaleDateString('pt-BR');
  }

  function escapeHtmlStr(str) {
    if (str == null) return '';
    const div = document.createElement('div');
    div.textContent = String(str);
    return div.innerHTML;
  }

  function formatarTamanhoArquivo(bytes) {
    if (bytes == null || bytes < 0) return '—';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1).replace('.', ',') + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1).replace('.', ',') + ' MB';
  }

  function lerArquivoComoDataUrl(file) {
    return new Promise(function(resolve, reject) {
      var reader = new FileReader();
      reader.onload = function() { resolve(reader.result); };
      reader.onerror = function() { reject(new Error('Falha ao ler arquivo.')); };
      reader.readAsDataURL(file);
    });
  }

  function montarLinkAnexo(nome, url, classe, prefixo) {
    if (!url) return '';
    var rotulo = (prefixo ? (prefixo + ': ') : '') + (nome || 'anexo');
    return '<a class="' + (classe || 'link-tabela') + '" href="' + escapeHtmlStr(url) + '" target="_blank" rel="noopener noreferrer" download="' + escapeHtmlStr(nome || 'anexo') + '">' +
      escapeHtmlStr(rotulo) + ' <span class="resolver-muted">(abrir/baixar)</span></a>';
  }

  /**
   * Chamados em que o e-mail logado é o solicitante (abertura pelo usuário).
   */
  function getChamadosSolicitadosPeloUsuario(email) {
    if (!email) return [];
    const e = String(email).toLowerCase();
    return getChamados().filter(function(c) {
      return c.solicitanteEmail && String(c.solicitanteEmail).toLowerCase() === e;
    });
  }

  function getUsuarioSessaoAtual() {
    try {
      const raw = sessionStorage.getItem(STORAGE_KEYS.usuario);
      return raw ? JSON.parse(raw) : null;
    } catch (_errUserSession) {
      return null;
    }
  }

  function usuarioEhAdministrador(usuario) {
    return !!(usuario && String(usuario.perfil || '').trim().toLowerCase() === 'administrador');
  }

  function usuarioPodeVerTodosChamados(usuario) {
    if (!usuario) return false;
    const perfil = String(usuario.perfil || '').trim().toLowerCase();
    return perfil === 'administrador' || perfil === 'coordenador';
  }

  function chamadoRecebidoPeloUsuario(chamado, usuario) {
    if (!chamado || !usuario) return false;
    const destinoNorm = normalizarTextoBase(chamado.setorDestino || '');
    if (!destinoNorm) return false;
    const candidatos = [];
    if (usuario.setor_nome) candidatos.push(usuario.setor_nome);
    if (usuario.setor_codigo) {
      const codigo = String(usuario.setor_codigo).trim().toLowerCase();
      candidatos.push(codigo);
      if (SETORES_LABEL[codigo]) candidatos.push(SETORES_LABEL[codigo]);
    }
    return candidatos.some(function(item) {
      const itemNorm = normalizarTextoBase(item);
      if (!itemNorm) return false;
      return destinoNorm === itemNorm || destinoNorm.includes(itemNorm) || itemNorm.includes(destinoNorm);
    });
  }

  function chamadoVisivelParaUsuario(chamado, usuario) {
    if (!usuario || !chamado) return false;
    if (usuarioPodeVerTodosChamados(usuario)) return true;
    const emailUser = normalizarTextoBase(usuario.email || '');
    const emailChamado = normalizarTextoBase(chamado.solicitanteEmail || '');
    const abertoPeloUsuario = !!(emailUser && emailChamado && emailUser === emailChamado);
    return abertoPeloUsuario || chamadoRecebidoPeloUsuario(chamado, usuario);
  }

  function filtrarChamadosPorUsuario(chamados, usuario) {
    if (!Array.isArray(chamados)) return [];
    const usuarioAtual = usuario || getUsuarioSessaoAtual();
    if (!usuarioAtual) return [];
    if (usuarioPodeVerTodosChamados(usuarioAtual)) return chamados.slice();
    return chamados.filter(function(chamado) {
      return chamadoVisivelParaUsuario(chamado, usuarioAtual);
    });
  }

  function classeStatusChamado(status) {
    const s = normalizarTextoBase(status);
    if (s.includes('atendimento')) return 'status-atendimento';
    if (s.includes('finalizado')) return 'status-finalizado';
    if (s.includes('critico')) return 'status-critico';
    return 'status-aberto';
  }

  function formatarQuandoTramitacao(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    return isNaN(d.getTime()) ? String(iso) : d.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
  }

  function getChamadoPorId(id) {
    return getChamados().find(function(c) { return c.id === id; });
  }

  function salvarChamadoParcial(id, parcial) {
    const chamados = getChamados();
    const idx = chamados.findIndex(function(c) { return c.id === id; });
    if (idx === -1) return false;
    chamados[idx] = Object.assign({}, chamados[idx], parcial);
    localStorage.setItem(STORAGE_KEYS.chamados, JSON.stringify(chamados));
    return true;
  }

  function adicionarTramitacao(id, entrada) {
    const chamados = getChamados();
    const idx = chamados.findIndex(function(c) { return c.id === id; });
    if (idx === -1) return false;
    const c = chamados[idx];
    const lista = Array.isArray(c.tramitacao) ? c.tramitacao.slice() : [];
    lista.unshift({
      quando: entrada.quando || new Date().toISOString(),
      texto: entrada.texto,
      porNome: entrada.porNome,
      porEmail: entrada.porEmail
    });
    c.tramitacao = lista;
    chamados[idx] = c;
    localStorage.setItem(STORAGE_KEYS.chamados, JSON.stringify(chamados));
    return true;
  }

  /* ========== INICIALIZAÇÃO AO CARREGAR A PÁGINA ========== */
  document.addEventListener('DOMContentLoaded', function() {

    /* --- Proteção de páginas (simulação de autenticação) ---
     * Bloqueia páginas internas quando não há usuário logado.
     * Redireciona para login.html e, após logar, volta para a página solicitada.
     */
    (function protegerPaginas() {
      const pagina = (window.location.pathname || '').split('/').pop() || 'index.html';
      const usuario = sessionStorage.getItem(STORAGE_KEYS.usuario);
      let usuarioObj = null;
      if (usuario) {
        try { usuarioObj = JSON.parse(usuario); } catch (_eUser) { usuarioObj = null; }
      }

      const paginasProtegidas = new Set([
        'dashboard.html',
        'abrir-chamado.html',
        'resolver-chamados.html',
        'listagem-chamados.html',
        'detalhes-chamado.html',
        'perfil.html',
        'usuarios-admin.html'
      ]);
      const paginasSomenteAdmin = new Set(['usuarios-admin.html']);

      // Se tentar acessar página protegida sem login, manda para login
      if (paginasProtegidas.has(pagina) && !usuario) {
        const next = encodeURIComponent(pagina + window.location.search);
        window.location.replace('login.html?next=' + next);
        return;
      }

      if (paginasSomenteAdmin.has(pagina) && usuarioObj && usuarioObj.perfil && usuarioObj.perfil !== 'administrador') {
        window.location.replace('dashboard.html');
        return;
      }

      // Se já estiver logado e tentar abrir login/registro, manda para dashboard
      if (usuario && (pagina === 'login.html' || pagina === 'registro.html')) {
        window.location.replace('dashboard.html');
      }
    })();

    /* --- Visibilidade do menu por autenticação ---
     * Esconde links de páginas protegidas na sidebar quando não há login.
     */
    (function controlarMenuAutenticacao() {
      const usuario = sessionStorage.getItem(STORAGE_KEYS.usuario);
      let usuarioObj = null;
      if (usuario) {
        try { usuarioObj = JSON.parse(usuario); } catch (_eParseUser) { usuarioObj = null; }
      }
      const isAdmin = !!(usuarioObj && String(usuarioObj.perfil || '').toLowerCase() === 'administrador');
      const paginasProtegidas = new Set([
        'dashboard.html',
        'abrir-chamado.html',
        'resolver-chamados.html',
        'listagem-chamados.html',
        'detalhes-chamado.html',
        'perfil.html',
        'usuarios-admin.html'
      ]);

      // Em páginas públicas (ex.: início), adiciona o bloco "Principal" quando logado.
      if (usuario) {
        const sidebar = document.querySelector('.sidebar');
        const jaTemLinksPrincipais = !!document.querySelector('.sidebar-nav a[href="dashboard.html"]');
        if (sidebar && !jaTemLinksPrincipais) {
          const primeiraSecao = sidebar.querySelector('.sidebar-section');
          const secaoPrincipal = document.createElement('div');
          secaoPrincipal.className = 'sidebar-section';
          secaoPrincipal.innerHTML =
            '<div class="sidebar-title">Principal</div>' +
            '<ul class="sidebar-nav">' +
              '<li><a href="dashboard.html"><svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>Dashboard</a></li>' +
              '<li><a href="abrir-chamado.html"><svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" /></svg>Abrir chamado</a></li>' +
              '<li><a href="resolver-chamados.html"><svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>Resolver chamados</a></li>' +
              '<li><a href="listagem-chamados.html"><svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>Chamados</a></li>' +
              '<li><a href="perfil.html"><svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>Perfil</a></li>' +
            '</ul>';

          if (primeiraSecao) {
            sidebar.insertBefore(secaoPrincipal, primeiraSecao);
          } else {
            sidebar.appendChild(secaoPrincipal);
          }
        }
      }

      document.querySelectorAll('.sidebar-section').forEach(function(section) {
        const titulo = section.querySelector('.sidebar-title');
        if (!titulo || normalizarTextoBase(titulo.textContent) !== 'principal') return;
        const nav = section.querySelector('.sidebar-nav');
        if (!nav) return;
        const jaTem = nav.querySelector('a[href="usuarios-admin.html"]');
        if (isAdmin && !jaTem) {
          const li = document.createElement('li');
          li.innerHTML = '<a href="usuarios-admin.html"><svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5V4H2v16h5m10 0v-2a4 4 0 00-8 0v2m8 0H9m8-10a4 4 0 11-8 0 4 4 0 018 0z"/></svg>Usuários</a>';
          nav.appendChild(li);
        }
        if (!isAdmin && jaTem) {
          const li = jaTem.closest('li');
          if (li) li.remove();
        }
      });

      document.querySelectorAll('.sidebar-nav a[href]').forEach(function(link) {
        const href = (link.getAttribute('href') || '').split('?')[0];
        if (!paginasProtegidas.has(href)) return;

        const item = link.closest('li');
        if (item) item.style.display = usuario ? '' : 'none';
      });

      // Se toda a seção "Principal" ficar vazia, oculta o título também.
      document.querySelectorAll('.sidebar-section').forEach(function(section) {
        const itens = section.querySelectorAll('.sidebar-nav li');
        const visiveis = Array.from(itens).some(function(li) {
          return li.style.display !== 'none';
        });
        if (!visiveis) section.style.display = 'none';
      });
    })();

    /* --- Topo da página inicial: Entrar / Registrar-se ---
     * Só exibe quando não há usuário logado (ex.: index.html).
     */
    (function atualizarBotoesTopoAuth() {
      const caixa = document.querySelector('.acoes-auth');
      if (!caixa) return;
      const usuario = sessionStorage.getItem(STORAGE_KEYS.usuario);
      caixa.style.display = usuario ? 'none' : '';
    })();

    /* --- Cabeçalho: chip do usuário logado ---
     * Atalho para o perfil à direita do topo (substitui visualmente o vazio após esconder Entrar/Registrar).
     */
    (function inserirChipUsuarioTopo() {
      function escapeHtml(str) {
        if (str == null) return '';
        const div = document.createElement('div');
        div.textContent = String(str);
        return div.innerHTML;
      }
      const usuarioRaw = sessionStorage.getItem(STORAGE_KEYS.usuario);
      if (!usuarioRaw) return;
      var u;
      try {
        u = JSON.parse(usuarioRaw);
      } catch (e) {
        return;
      }
      var nome = u.nome || (u.email ? u.email.split('@')[0] : '') || 'Usuário';
      nome = String(nome);
      document.querySelectorAll('.acoes-topo').forEach(function(topo) {
        if (topo.querySelector('.chip-usuario-logado')) return;
        var a = document.createElement('a');
        a.href = 'perfil.html';
        a.className = 'chip-usuario-logado';
        a.setAttribute('aria-label', 'Meu perfil — ' + nome);
        a.innerHTML =
          '<span class="chip-usuario-avatar" aria-hidden="true">' +
          '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="18" height="18"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>' +
          '</span><span class="chip-usuario-nome">' + escapeHtml(nome) + '</span>';
        topo.appendChild(a);
      });
    })();

    /* --- Sidebar (menu lateral) ---
     * Mobile: abre/fecha e salva preferência.
     */
    (function initSidebar() {
      const key = 'flowset_sidebar_open';
      const btnMenu = document.getElementById('btn-menu');
      const overlay = document.querySelector('.sidebar-overlay');

      function setOpen(open) {
        document.body.classList.toggle('sidebar-open', !!open);
        localStorage.setItem(key, open ? '1' : '0');
        if (btnMenu) btnMenu.setAttribute('aria-expanded', open ? 'true' : 'false');
      }

      // Restaura apenas em telas pequenas (em desktop sidebar já é fixa)
      const isMobile = window.matchMedia && window.matchMedia('(max-width: 980px)').matches;
      if (isMobile) {
        const saved = localStorage.getItem(key);
        if (saved === '1') setOpen(true);
      }

      if (btnMenu) {
        btnMenu.addEventListener('click', function() {
          setOpen(!document.body.classList.contains('sidebar-open'));
        });
      }
      if (overlay) {
        overlay.addEventListener('click', function() { setOpen(false); });
      }
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') setOpen(false);
      });
    })();

    /* --- Tema (claro/escuro) ---
     * Salva preferência em localStorage e aplica em <html data-theme="...">.
     */
    (function initTema() {
      const key = 'flowset_tema';
      const root = document.documentElement;
      const saved = localStorage.getItem(key);
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      const temaInicial = saved || (prefersDark ? 'dark' : 'light');
      root.setAttribute('data-theme', temaInicial);

      function syncIconsAll() {
        const isDark = root.getAttribute('data-theme') === 'dark';
        document.querySelectorAll('[data-theme-toggle]').forEach(function(btn) {
          const iconSun = btn.querySelector('.icon-sun');
          const iconMoon = btn.querySelector('.icon-moon');
          if (iconSun && iconMoon) {
            iconSun.style.display = isDark ? 'block' : 'none';
            iconMoon.style.display = isDark ? 'none' : 'block';
          }
          btn.setAttribute('aria-label', isDark ? 'Ativar tema claro' : 'Ativar tema escuro');
        });
      }

      syncIconsAll();

      document.querySelectorAll('[data-theme-toggle]').forEach(function(btn) {
        btn.addEventListener('click', function() {
          const isDark = root.getAttribute('data-theme') === 'dark';
          const next = isDark ? 'light' : 'dark';
          root.setAttribute('data-theme', next);
          localStorage.setItem(key, next);
          syncIconsAll();
        });
      });
    })();

    /* --- Menu ativo ---
     * Marca o link do menu correspondente à página atual.
     */
    (function marcarMenuAtivo() {
      const path = (window.location.pathname || '').split('/').pop() || 'index.html';
      document.querySelectorAll('.nav-principal a[href], .sidebar-nav a[href]').forEach(function(a) {
        const href = (a.getAttribute('href') || '').split('?')[0];
        if (href === path) a.classList.add('is-active');
      });
    })();

    /* --- Toggle visibilidade da senha ---
     * Permite mostrar/ocultar a senha nos campos de login e registro.
     * Alterna entre type="password" e type="text" e troca o ícone do botão.
     */
    document.querySelectorAll('.btn-toggle-senha').forEach(function(btn) {
      btn.addEventListener('click', function() {
        const wrapper = this.closest('.input-wrapper');
        const input = wrapper ? wrapper.querySelector('input') : null;
        const iconShow = this.querySelector('.icon-show');
        const iconHide = this.querySelector('.icon-hide');
        if (!input) return;

        const isPassword = input.type === 'password';
        input.type = isPassword ? 'text' : 'password';

        if (iconShow && iconHide) {
          iconShow.style.display = isPassword ? 'none' : 'block';
          iconHide.style.display = isPassword ? 'block' : 'none';
        }
      });
    });

    /* --- Login ---
     * Intercepta o envio do formulário de login.
     * Salva usuário na sessão (sessionStorage) e redireciona para o dashboard.
     * Em produção: validar credenciais no backend.
     */
    const formLogin = document.querySelector('form[action="dashboard.html"]');
    if (formLogin && formLogin.querySelector('#email')) {
      formLogin.addEventListener('submit', async function(e) {
        e.preventDefault();
        const email = formLogin.querySelector('#email').value;
        const senha = formLogin.querySelector('#senha').value;
        if (email && senha) {
          try {
            const data = await apiRequest('/login', {
              method: 'POST',
              body: JSON.stringify({ email: email, senha: senha })
            });
            salvarSessaoApi(data.token, data.usuario);
          } catch (apiErr) {
            if (apiErr && apiErr.status && apiErr.status < 500) {
              setFormFeedback(formLogin, apiErr.message || 'Falha no login.', 'erro');
              return;
            }
            if (!podeUsarFallbackLocal(apiErr)) {
              setFormFeedback(formLogin, apiErr.message || 'API indisponível para login.', 'erro');
              return;
            }
            sessionStorage.setItem(STORAGE_KEYS.usuario, JSON.stringify({ email, nome: email.split('@')[0] }));
            setFormFeedback(formLogin, 'API indisponível. Login efetuado em modo local.', 'alerta');
          }
          const params = new URLSearchParams(window.location.search);
          const next = params.get('next');
          window.location.href = next ? decodeURIComponent(next) : 'dashboard.html';
        }
      });
    }

    /* --- Página Perfil ---
     * Exibe nome/e-mail da sessão e encerra o login local.
     */
    const elPerfilNome = document.getElementById('perfil-nome');
    if (elPerfilNome) {
      (async function carregarPerfil() {
      try {
        try {
          const dataMe = await apiRequest('/me');
          if (dataMe && dataMe.usuario) {
            const uApi = dataMe.usuario;
            sessionStorage.setItem(STORAGE_KEYS.usuario, JSON.stringify({
              id: uApi.id,
              nome: uApi.nome,
              email: uApi.email,
              perfil: uApi.perfil,
              setor_id: uApi.setor_id || null,
              setor_codigo: uApi.setor_codigo || null,
              setor_nome: uApi.setor_nome || null
            }));
          }
        } catch (_meErr) {
          if (STRICT_API) {
            showPageNotice('Não foi possível carregar o perfil pela API.', 'erro');
          }
        }

        const raw = sessionStorage.getItem(STORAGE_KEYS.usuario);
        const u = raw ? JSON.parse(raw) : null;
        const nomeEl = document.getElementById('perfil-nome');
        const emailEl = document.getElementById('perfil-email');
        if (u && nomeEl && emailEl) {
          nomeEl.textContent = u.nome || (u.email ? u.email.split('@')[0] : '') || 'Usuário';
          emailEl.textContent = u.email || '—';
        }

        const ulHist = document.getElementById('perfil-historico-lista');
        if (ulHist && u && u.email) {
          const meus = getChamadosSolicitadosPeloUsuario(u.email);
          if (meus.length === 0) {
            ulHist.innerHTML = '<li class="perfil-historico-vazio">Você ainda não abriu nenhum chamado. <a href="abrir-chamado.html">Abrir chamado</a></li>';
          } else {
            ulHist.innerHTML = meus.map(function(c) {
              const stCl = classeStatusChamado(c.status);
              const stLabel = padronizarStatus(c.status);
              return '<li class="historico-item perfil-chamado-item">' +
                '<a href="detalhes-chamado.html?id=' + encodeURIComponent(c.id) + '" class="perfil-chamado-link">' +
                '<div class="perfil-chamado-linha1">' +
                '<strong class="perfil-chamado-id">' + escapeHtmlStr(c.id) + '</strong> ' +
                '<span class="status ' + stCl + '">' + escapeHtmlStr(stLabel) + '</span></div>' +
                '<div class="data">' + escapeHtmlStr(c.tipo || '') + ' — ' + escapeHtmlStr(c.setorDestino || '') + '</div>' +
                '<div class="perfil-chamado-meta">Abertura: ' + escapeHtmlStr(c.dataAbertura || '—') + ' · Prazo: ' + escapeHtmlStr(c.prazo || '—') + '</div>' +
                '</a></li>';
            }).join('');
          }
        }
      } catch (e) { /* ignore JSON inválido */ }
      })();
      const btnSair = document.getElementById('btn-sair-perfil');
      if (btnSair) {
        btnSair.addEventListener('click', function() {
          sessionStorage.removeItem(STORAGE_KEYS.usuario);
          sessionStorage.removeItem(STORAGE_KEYS.token);
          localStorage.removeItem(STORAGE_KEYS.token);
          window.location.href = 'index.html';
        });
      }
    }

    /* --- Registro ---
     * Valida se as senhas coincidem antes de enviar.
     * Salva o novo usuário em flowset_usuarios e redireciona para login.
     * Em produção: enviar para API e usar hash de senha.
     */
    const formRegistro = document.querySelector('form[action="login.html"]');
    if (formRegistro && formRegistro.querySelector('#confirmar-senha')) {
      const nomeInput = formRegistro.querySelector('#nome');
      const emailInput = formRegistro.querySelector('#email');
      const setorInput = formRegistro.querySelector('#setor-id');
      const senhaInput = formRegistro.querySelector('#senha');
      const confirmarInput = formRegistro.querySelector('#confirmar-senha');
      const senhaStrengthBar = formRegistro.querySelector('#senha-strength-bar');
      const senhaStrengthText = formRegistro.querySelector('#senha-strength-text');
      const submitBtn = formRegistro.querySelector('button[type="submit"]');

      function validarNome(nome) {
        const n = String(nome || '').trim();
        return n.length >= 3 && /\s+/.test(n);
      }

      function validarEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || '').trim());
      }

      function avaliarForcaSenha(senha) {
        const v = String(senha || '');
        let score = 0;
        if (v.length >= 8) score += 1;
        if (/[A-Z]/.test(v)) score += 1;
        if (/[a-z]/.test(v)) score += 1;
        if (/\d/.test(v)) score += 1;
        if (/[^A-Za-z0-9]/.test(v)) score += 1;
        return score;
      }

      function senhaAtendePolitica(senha) {
        const v = String(senha || '');
        return v.length >= 8 && /[A-Z]/.test(v) && /[a-z]/.test(v) && /\d/.test(v);
      }

      function atualizarForcaSenha() {
        if (!senhaInput || !senhaStrengthBar || !senhaStrengthText) return;
        const score = avaliarForcaSenha(senhaInput.value);
        const porcentagem = Math.max(8, score * 20);
        senhaStrengthBar.style.width = porcentagem + '%';
        if (score <= 2) {
          senhaStrengthBar.style.backgroundColor = '#dc2626';
          senhaStrengthText.textContent = 'Senha fraca: inclua maiúscula, minúscula, número e 8+ caracteres.';
        } else if (score <= 4) {
          senhaStrengthBar.style.backgroundColor = '#d97706';
          senhaStrengthText.textContent = 'Senha média: adicione caractere especial para maior segurança.';
        } else {
          senhaStrengthBar.style.backgroundColor = '#16a34a';
          senhaStrengthText.textContent = 'Senha forte: ótimo nível de segurança.';
        }
      }

      function atualizarBotaoCadastro() {
        if (!submitBtn) return;
        const nomeOk = validarNome(nomeInput?.value || '');
        const emailOk = validarEmail(emailInput?.value || '');
        const setorOk = !!(setorInput && setorInput.value);
        const senhaOk = senhaAtendePolitica(senhaInput?.value || '');
        const confirmOk = !!confirmarInput && confirmarInput.value === senhaInput?.value;
        submitBtn.disabled = !(nomeOk && emailOk && setorOk && senhaOk && confirmOk);
      }

      async function carregarSetoresRegistro() {
        if (!setorInput) return;
        try {
          const setores = await carregarSetoresAtivos();
          preencherSelectSetores(setorInput, setores, 'Selecione seu setor');
        } catch (_setoresErr) {
          setorInput.innerHTML = '<option value="">Não foi possível carregar setores</option>';
          setorInput.disabled = true;
          if (STRICT_API) {
            setFormFeedback(formRegistro, 'Não foi possível carregar os setores para cadastro.', 'erro');
          }
        } finally {
          atualizarBotaoCadastro();
        }
      }

      formRegistro.addEventListener('submit', async function(e) {
        e.preventDefault();
        clearFormFeedback(formRegistro);

        const nome = String(nomeInput?.value || '').trim();
        const email = String(emailInput?.value || '').trim().toLowerCase();
        const setorOption = setorInput && setorInput.selectedIndex >= 0 ? setorInput.options[setorInput.selectedIndex] : null;
        const setorId = setorOption?.dataset?.setorId || '';
        const setorCodigo = setorOption?.value || '';
        const setorNome = setorOption?.textContent || '';
        const senha = String(senhaInput?.value || '');
        const confirmar = String(confirmarInput?.value || '');

        if (!validarNome(nome)) {
          setFormFeedback(formRegistro, 'Informe nome completo (nome e sobrenome).', 'erro');
          nomeInput?.focus();
          return;
        }
        if (!validarEmail(email)) {
          setFormFeedback(formRegistro, 'Informe um e-mail válido.', 'erro');
          emailInput?.focus();
          return;
        }
        if (!setorId) {
          setFormFeedback(formRegistro, 'Selecione seu setor antes de continuar.', 'erro');
          setorInput?.focus();
          return;
        }
        if (!senhaAtendePolitica(senha)) {
          setFormFeedback(formRegistro, 'Crie uma senha com 8+ caracteres, letra maiúscula, minúscula e número.', 'erro');
          senhaInput?.focus();
          return;
        }
        if (senha !== confirmar) {
          if (confirmarInput) {
            confirmarInput.setCustomValidity('As senhas não coincidem');
            confirmarInput.reportValidity();
          }
          setFormFeedback(formRegistro, 'As senhas informadas não coincidem.', 'erro');
          return;
        }
        if (confirmarInput) confirmarInput.setCustomValidity('');

        try {
          setButtonLoading(submitBtn, true, 'Registrando...');
          await apiRequest('/registro', {
            method: 'POST',
            body: JSON.stringify({ nome: nome, email: email, senha: senha, setor_id: Number(setorId) })
          });
          setFormFeedback(formRegistro, 'Cadastro realizado com sucesso. Redirecionando para o login...', 'sucesso');
        } catch (apiErr) {
          if (apiErr && apiErr.status && apiErr.status < 500) {
            setFormFeedback(formRegistro, apiErr.message || 'Falha no cadastro.', 'erro');
            return;
          }
          if (!podeUsarFallbackLocal(apiErr)) {
            setFormFeedback(formRegistro, apiErr.message || 'API indisponível para cadastro.', 'erro');
            return;
          }
          const usuarios = JSON.parse(localStorage.getItem('flowset_usuarios') || '[]');
          usuarios.push({ nome, email, senha: '***', setor_id: Number(setorId), setor_codigo: setorCodigo, setor_nome: setorNome });
          localStorage.setItem('flowset_usuarios', JSON.stringify(usuarios));
          setFormFeedback(formRegistro, 'API indisponível. Cadastro salvo em modo local.', 'alerta');
        } finally {
          setButtonLoading(submitBtn, false);
        }

        setTimeout(function() {
          window.location.href = 'login.html';
        }, 700);
      });

      if (nomeInput) {
        nomeInput.addEventListener('input', function() {
          atualizarBotaoCadastro();
        });
      }
      if (emailInput) {
        emailInput.addEventListener('input', function() {
          atualizarBotaoCadastro();
        });
      }
      if (setorInput) {
        setorInput.addEventListener('change', function() {
          atualizarBotaoCadastro();
        });
      }
      if (senhaInput) {
        senhaInput.addEventListener('input', function() {
          if (confirmarInput && confirmarInput.value && confirmarInput.value !== senhaInput.value) {
            confirmarInput.setCustomValidity('As senhas não coincidem');
          } else if (confirmarInput) {
            confirmarInput.setCustomValidity('');
          }
          atualizarForcaSenha();
          atualizarBotaoCadastro();
        });
      }
      if (confirmarInput) {
        confirmarInput.addEventListener('input', function() {
          if (senhaInput && confirmarInput.value !== senhaInput.value) {
            confirmarInput.setCustomValidity('As senhas não coincidem');
          } else {
            confirmarInput.setCustomValidity('');
          }
          atualizarBotaoCadastro();
        });
      }

      atualizarForcaSenha();
      atualizarBotaoCadastro();
      carregarSetoresRegistro();
    }

    /* --- Abrir chamado ---
     * Intercepta o envio do formulário de abertura de chamado.
     * Gera ID sequencial (ano-número), salva no localStorage e redireciona para listagem.
     */
    const inputAnexosChamado = document.getElementById('anexos-chamado');
    const previewAnexos = document.getElementById('anexos-chamado-preview');
    if (inputAnexosChamado && previewAnexos) {
      inputAnexosChamado.addEventListener('change', function() {
        previewAnexos.innerHTML = '';
        if (!this.files || !this.files.length) return;
        for (var i = 0; i < this.files.length; i++) {
          var f = this.files[i];
          var li = document.createElement('li');
          li.textContent = f.name + ' (' + formatarTamanhoArquivo(f.size) + ')';
          previewAnexos.appendChild(li);
        }
      });
    }

    const formChamado = document.querySelector('.formulario-chamado');
    if (formChamado) {
      const setorSolicitante = formChamado.querySelector('#setor-solicitante');
      const setorResponsavel = formChamado.querySelector('#setor-responsavel');
      const solicitante = formChamado.querySelector('#solicitante');
      const draftKey = STORAGE_KEYS.draftAbertura;

      async function carregarSetoresFormularioChamado() {
        if (!setorSolicitante || !setorResponsavel) return;
        const valorAtualSol = setorSolicitante.value;
        const valorAtualResp = setorResponsavel.value;
        try {
          const setores = await carregarSetoresAtivos();
          if (!setores.length) return;
          preencherSelectSetores(setorSolicitante, setores, 'Selecione o setor');
          preencherSelectSetores(setorResponsavel, setores, 'Selecione o setor');

          if (valorAtualSol && setorSolicitante.querySelector('option[value="' + valorAtualSol + '"]')) {
            setorSolicitante.value = valorAtualSol;
          }
          if (valorAtualResp && setorResponsavel.querySelector('option[value="' + valorAtualResp + '"]')) {
            setorResponsavel.value = valorAtualResp;
          }
        } catch (_setoresErr) {
          if (STRICT_API) {
            setFormFeedback(formChamado, 'Não foi possível carregar os setores da API.', 'erro');
          }
        }
      }

      function aplicarSetorDoUsuarioLogado() {
        if (!setorSolicitante || !setorSolicitante.value) {
          const usuario = getUsuarioSessaoAtual();
          const setorCodigo = usuario && usuario.setor_codigo ? String(usuario.setor_codigo) : '';
          if (setorCodigo && setorSolicitante && setorSolicitante.querySelector('option[value="' + setorCodigo + '"]')) {
            setorSolicitante.value = setorCodigo;
            atualizarSolicitantesPorSetor();
          }
        }
      }

      function restaurarDraftAbertura() {
        try {
          var raw = localStorage.getItem(draftKey);
          if (!raw) return;
          var draft = JSON.parse(raw);
          if (!draft || typeof draft !== 'object') return;
          ['setor-solicitante', 'setor-responsavel', 'tipo', 'prioridade', 'descricao', 'prazo'].forEach(function(id) {
            var el = formChamado.querySelector('#' + id);
            if (el && draft[id] != null) el.value = draft[id];
          });
          if (setorSolicitante && solicitante) {
            atualizarSolicitantesPorSetor();
            if (draft['solicitante'] && !solicitante.disabled) {
              solicitante.value = draft['solicitante'];
            }
          }
          setFormFeedback(formChamado, 'Rascunho recuperado automaticamente.', 'alerta');
        } catch (_errDraft) {
          localStorage.removeItem(draftKey);
        }
      }

      function salvarDraftAbertura() {
        var data = {
          'setor-solicitante': formChamado.querySelector('#setor-solicitante')?.value || '',
          'solicitante': formChamado.querySelector('#solicitante')?.value || '',
          'setor-responsavel': formChamado.querySelector('#setor-responsavel')?.value || '',
          'tipo': formChamado.querySelector('#tipo')?.value || '',
          'prioridade': formChamado.querySelector('#prioridade')?.value || '',
          'descricao': formChamado.querySelector('#descricao')?.value || '',
          'prazo': formChamado.querySelector('#prazo')?.value || '',
          quando: new Date().toISOString()
        };
        localStorage.setItem(draftKey, JSON.stringify(data));
      }

      function atualizarSolicitantesPorSetor() {
        if (!setorSolicitante || !solicitante) return;

        const setorSelecionado = setorSolicitante.value;
        const colaboradores = listarColaboradoresPorSetor(setorSelecionado);
        solicitante.innerHTML = '';

        if (!setorSelecionado) {
          solicitante.disabled = true;
          solicitante.required = true;
          solicitante.insertAdjacentHTML('beforeend', '<option value="">Selecione o setor primeiro</option>');
          return;
        }

        if (!colaboradores.length) {
          solicitante.disabled = true;
          solicitante.required = false;
          solicitante.insertAdjacentHTML('beforeend', '<option value="">Nenhum colaborador cadastrado para este setor</option>');
          return;
        }

        solicitante.disabled = false;
        solicitante.required = true;
        solicitante.insertAdjacentHTML('beforeend', '<option value="">Selecione o solicitante</option>');
        colaboradores.forEach(function(nome) {
          const option = document.createElement('option');
          option.value = nome;
          option.textContent = nome;
          solicitante.appendChild(option);
        });
      }

      if (setorSolicitante && solicitante) {
        setorSolicitante.addEventListener('change', atualizarSolicitantesPorSetor);
        window.addEventListener('storage', function(ev) {
          if (ev && ev.key && ev.key !== STORAGE_LOCAL_USERS_KEY && ev.key !== STORAGE_KEYS.usuario) return;
          atualizarSolicitantesPorSetor();
        });
        window.addEventListener('focus', atualizarSolicitantesPorSetor);
      }

      formChamado.querySelectorAll('input, select, textarea').forEach(function(el) {
        if (el.type === 'file') return;
        el.addEventListener('input', salvarDraftAbertura);
        el.addEventListener('change', salvarDraftAbertura);
      });

      (async function inicializarFormularioChamado() {
        await carregarSetoresFormularioChamado();
        restaurarDraftAbertura();
        aplicarSetorDoUsuarioLogado();
        atualizarSolicitantesPorSetor();
      })();

      formChamado.addEventListener('submit', async function(e) {
        e.preventDefault();
        clearFormFeedback(formChamado);
        const setorSol = formChamado.querySelector('#setor-solicitante');
        const solicitanteSelect = formChamado.querySelector('#solicitante');
        const setorResp = formChamado.querySelector('#setor-responsavel');
        const tipo = formChamado.querySelector('#tipo');
        const prioridade = formChamado.querySelector('#prioridade');
        const descricao = formChamado.querySelector('#descricao').value.trim();
        const prazo = formChamado.querySelector('#prazo').value;
        const btnSubmit = formChamado.querySelector('button[type="submit"]');

        if (setorSol.value && setorResp.value && setorSol.value === setorResp.value) {
          setFormFeedback(formChamado, 'O setor solicitante deve ser diferente do setor responsável.', 'erro');
          return;
        }
        if (descricao.length < 15) {
          setFormFeedback(formChamado, 'Descreva a solicitação com pelo menos 15 caracteres.', 'erro');
          return;
        }
        if (prazo && isPastDateInputValue(prazo)) {
          setFormFeedback(formChamado, 'O prazo não pode ser uma data anterior a hoje.', 'erro');
          return;
        }

        setButtonLoading(btnSubmit, true, 'Enviando chamado...');
        try {

        const setorSolLabel = setorSol.options[setorSol.selectedIndex]?.text || setorSol.value;
        const setorRespLabel = setorResp.options[setorResp.selectedIndex]?.text || setorResp.value;
        const tipoLabel = tipo.options[tipo.selectedIndex]?.text || tipo.value;
        const prioridadeLabel = padronizarPrioridade(prioridade.options[prioridade.selectedIndex]?.text || prioridade.value);

        var inputAnexos = document.getElementById('anexos-chamado');
        var anexosMeta = [];
        var maxAnexos = 5;
        var maxBytes = 10 * 1024 * 1024;
        if (inputAnexos && inputAnexos.files && inputAnexos.files.length) {
          if (inputAnexos.files.length > maxAnexos) {
            setFormFeedback(formChamado, 'No máximo ' + maxAnexos + ' arquivos por chamado.', 'erro');
            return;
          }
          for (var ia = 0; ia < inputAnexos.files.length; ia++) {
            var arq = inputAnexos.files[ia];
            if (arq.size > maxBytes) {
              setFormFeedback(formChamado, 'O arquivo "' + arq.name + '" ultrapassa 10 MB. Escolha um arquivo menor.', 'erro');
              return;
            }
            var conteudoDataUrl = null;
            try {
              conteudoDataUrl = await lerArquivoComoDataUrl(arq);
            } catch (_readErr) {
              conteudoDataUrl = null;
            }
            anexosMeta.push({
              nome: arq.name,
              tamanho: arq.size,
              tipo: arq.type || 'application/octet-stream',
              conteudo: conteudoDataUrl
            });
          }
        }

        var solicitanteEmail = null;
        var solicitanteNome = null;
        try {
          const rawU = sessionStorage.getItem(STORAGE_KEYS.usuario);
          const uForm = rawU ? JSON.parse(rawU) : null;
          if (uForm && uForm.email) {
            solicitanteEmail = uForm.email;
            solicitanteNome = uForm.nome || uForm.email.split('@')[0];
          }
        } catch (err) { /* ignore */ }

        const solicitanteSelecionado = solicitanteSelect ? solicitanteSelect.value.trim() : '';
        if (solicitanteSelecionado) {
          solicitanteNome = solicitanteSelecionado;
        }

        const payloadApi = {
          setor_solicitante: setorSol.value,
          setor_responsavel: setorResp.value,
          tipo: tipo.value,
          prioridade: prioridade.value,
          descricao: descricao,
          prazo: prazo,
          anexos: anexosMeta
        };

        try {
          await apiRequest('/chamados', {
            method: 'POST',
            body: JSON.stringify(payloadApi)
          });
        } catch (apiErr) {
          if (apiErr && apiErr.status && apiErr.status < 500) {
            setFormFeedback(formChamado, apiErr.message || 'Não foi possível abrir o chamado.', 'erro');
            return;
          }
          if (!podeUsarFallbackLocal(apiErr)) {
            setFormFeedback(formChamado, apiErr.message || 'API indisponível para abertura de chamado.', 'erro');
            return;
          }
          let chamados = getChamados();
          if (chamados.length === 0) chamados = getChamadosIniciais();

          let proximoId = localStorage.getItem(STORAGE_KEYS.proximoId) || '2025-0043';
          const ano = proximoId.split('-')[0];
          const num = parseInt(proximoId.split('-')[1]) + 1;
          const novoId = ano + '-' + String(num).padStart(4, '0');
          localStorage.setItem(STORAGE_KEYS.proximoId, ano + '-' + String(num + 1).padStart(4, '0'));

          const tramitacaoInicial = [{
            quando: new Date().toISOString(),
            texto: 'Chamado aberto e encaminhado ao setor ' + setorRespLabel + '.',
            porEmail: solicitanteEmail,
            porNome: solicitanteNome
          }];

          const novoChamado = {
            id: novoId,
            setorOrigem: setorSolLabel,
            setorDestino: setorRespLabel,
            status: 'Aberto',
            prioridade: prioridadeLabel,
            prazo: formatarData(prazo),
            tipo: tipoLabel,
            descricao: descricao,
            dataAbertura: new Date().toLocaleDateString('pt-BR'),
            solicitanteEmail: solicitanteEmail,
            solicitanteNome: solicitanteNome,
            anexos: anexosMeta.length ? anexosMeta : undefined,
            tramitacao: tramitacaoInicial
          };

          chamados.unshift(novoChamado);
          localStorage.setItem(STORAGE_KEYS.chamados, JSON.stringify(chamados));
          setFormFeedback(formChamado, 'API indisponível. Chamado salvo em modo local.', 'alerta');
        }
        localStorage.removeItem(draftKey);
        window.location.href = 'listagem-chamados.html';
        } finally {
          setButtonLoading(btnSubmit, false);
        }
      });
    }

    /* --- Resolver e encaminhar chamados ---
     * Cards com status, encaminhamento e observação (salva tramitacao no localStorage).
     */
    (function initResolverChamados() {

      function classeCardResolver(st) {
        const s = (st || '').toLowerCase();
        if (s.includes('finalizado')) return 'card-resolver--finalizado';
        if (s.includes('crítico')) return 'card-resolver--critico';
        if (s.includes('atendimento')) return 'card-resolver--atendimento';
        return 'card-resolver--aberto';
      }

      function classePriorChip(p) {
        const x = normalizarTextoBase(p);
        if (x.includes('critica') || (x.includes('alta') && !x.includes('baixa'))) return 'resolver-chip--alta';
        if (x.includes('media')) return 'resolver-chip--media';
        return 'resolver-chip--baixa';
      }

      function matchFiltroStatus(c, filtro) {
        if (!filtro) return true;
        const s = (c.status || '').toLowerCase();
        if (filtro === 'aberto') return s === 'aberto' || (s.includes('aberto') && !s.includes('atendimento'));
        if (filtro === 'atendimento') return s.includes('atendimento');
        if (filtro === 'critico') return s.includes('crítico');
        if (filtro === 'finalizado') return s.includes('finalizado');
        return true;
      }

      function matchBusca(c, q) {
        if (!q) return true;
        const blob = [c.id, c.tipo, c.setorOrigem, c.setorDestino, c.descricao || '', c.solicitanteEmail || '', c.solicitanteNome || ''].join(' ').toLowerCase();
        return blob.indexOf(q) !== -1;
      }

      async function renderStatsBar(chamadosBase) {
        const el = document.getElementById('resolver-stats-bar');
        if (!el) return;
        const todos = Array.isArray(chamadosBase) ? chamadosBase : await getChamadosPreferApi();
        const n = { aberto: 0, atendimento: 0, critico: 0, finalizado: 0 };
        todos.forEach(function(c) {
          const s = (c.status || '').toLowerCase();
          if (s.includes('finalizado')) n.finalizado++;
          else if (s.includes('crítico')) n.critico++;
          else if (s.includes('atendimento')) n.atendimento++;
          else n.aberto++;
        });
        el.innerHTML =
          '<div class="resolver-stat resolver-stat--aberto"><span class="resolver-stat-val">' + n.aberto + '</span><span class="resolver-stat-lbl">Abertos</span></div>' +
          '<div class="resolver-stat resolver-stat--atend"><span class="resolver-stat-val">' + n.atendimento + '</span><span class="resolver-stat-lbl">Em atendimento</span></div>' +
          '<div class="resolver-stat resolver-stat--crit"><span class="resolver-stat-val">' + n.critico + '</span><span class="resolver-stat-lbl">Críticos</span></div>' +
          '<div class="resolver-stat resolver-stat--fin"><span class="resolver-stat-val">' + n.finalizado + '</span><span class="resolver-stat-lbl">Finalizados</span></div>';
      }

      function montarHtmlCardResolver(c) {
        const st = padronizarStatus(c.status || 'Aberto');
        const stCl = classeStatusChamado(st);
        const sol = (c.solicitanteNome || c.solicitanteEmail || '').toString();
        const anexos = Array.isArray(c.anexos) ? c.anexos : [];
        const htmlAnexos = anexos.length
          ? anexos.map(function(a, idx) {
              if (!a || !a.nome) return '';
              var url = a.conteudo || a.url || '';
              if (url) {
                return montarLinkAnexo(a.nome, url, 'link-tabela', 'Anexo ' + (idx + 1));
              }
              return '<span class="resolver-muted">Anexo ' + (idx + 1) + ': ' + escapeHtmlStr(a.nome) + ' (sem visualização disponível)</span>';
            }).filter(Boolean).join('<br>')
          : '<span class="resolver-muted">Sem anexos</span>';
        const idEsc = escapeHtmlStr(c.id);
        const idSafe = String(c.id).replace(/[^a-zA-Z0-9]/g, '_');
        const optsHtml = STATUS_OPTS.map(function(o) {
          const rotulo = padronizarStatus(o);
          return '<option value="' + escapeHtmlStr(rotulo) + '"' + (rotulo === st ? ' selected' : '') + '>' + escapeHtmlStr(rotulo) + '</option>';
        }).join('');
        return '<article class="card-resolver ' + classeCardResolver(st) + '" data-chamado-id="' + idEsc + '">' +
          '<div class="card-resolver-top">' +
          '<div class="card-resolver-id-row">' +
          '<span class="resolver-num">#' + idEsc + '</span>' +
          '<span class="status ' + stCl + '">' + escapeHtmlStr(st) + '</span>' +
          '<a class="resolver-detalhes-link" href="detalhes-chamado.html?id=' + encodeURIComponent(c.id) + '">Ver detalhes</a>' +
          '</div>' +
          '<div class="resolver-chips">' +
          '<span class="resolver-chip">' + escapeHtmlStr(c.tipo || '—') + '</span>' +
          '<span class="resolver-chip ' + classePriorChip(c.prioridade) + '">' + escapeHtmlStr(padronizarPrioridade(c.prioridade || '—')) + '</span>' +
          '<span class="resolver-chip resolver-chip-prazo">Prazo ' + escapeHtmlStr(c.prazo || '—') + '</span>' +
          '</div>' +
          '<p class="resolver-meta">' + escapeHtmlStr(c.setorOrigem || '') + ' → ' + escapeHtmlStr(c.setorDestino || '') + '</p>' +
          '</div>' +
          '<div class="card-resolver-corpo">' +
          '<p class="resolver-solicitante-line"><strong>Solicitante:</strong> ' + (sol ? escapeHtmlStr(sol) : '—') +
          (c.solicitanteEmail ? ' <span class="resolver-muted">(' + escapeHtmlStr(c.solicitanteEmail) + ')</span>' : '') + '</p>' +
          '<p class="resolver-enc-atual"><strong>Anexos:</strong><br>' + htmlAnexos + '</p>' +
          '<p class="resolver-descricao-snippet">' + escapeHtmlStr((c.descricao || '').slice(0, 220)) + ((c.descricao || '').length > 220 ? '…' : '') + '</p>' +
          '</div>' +
          '<div class="card-resolver-acoes">' +
          '<h3 class="resolver-acoes-titulo">Ações</h3>' +
          '<form class="form-resolver-chamado" data-chamado-id="' + idEsc + '" data-status-atual="' + escapeHtmlStr(st) + '">' +
          '<div class="grupo-campo"><label for="st-' + idSafe + '">Novo status</label><select id="st-' + idSafe + '" name="status_novo" required>' + optsHtml + '</select></div>' +
          '<div class="grupo-campo"><label for="ob-' + idSafe + '">Descrição da resolução</label><textarea id="ob-' + idSafe + '" name="observacao" rows="3" placeholder="Descreva como o chamado foi resolvido."></textarea></div>' +
          '<div class="resolver-form-botoes">' +
          '<button type="submit" class="botao"><svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>Salvar alterações</button>' +
          '</div></form></div></article>';
      }

      async function renderizarPaginaResolver() {
        const container = document.getElementById('resolver-chamados-container');
        const chk = document.getElementById('resolver-mostrar-finalizados');
        const inpBusca = document.getElementById('resolver-busca');
        const selStatus = document.getElementById('resolver-filtro-status');
        const contador = document.getElementById('resolver-contador');
        if (!container) return;

        const todosChamados = filtrarChamadosPorUsuario(await getChamadosPreferApi());
        await renderStatsBar(todosChamados);

        const mostrarTodos = chk && chk.checked;
        const filtroSt = selStatus ? selStatus.value : '';
        const q = (inpBusca && inpBusca.value) ? inpBusca.value.trim().toLowerCase() : '';

        let lista = todosChamados.filter(function(c) {
          if (mostrarTodos) return true;
          return !(c.status || '').toLowerCase().includes('finalizado');
        });
        lista = lista.filter(function(c) { return matchFiltroStatus(c, filtroSt); });
        lista = lista.filter(function(c) { return matchBusca(c, q); });
        lista = lista.slice().sort(function(a, b) {
          return (b.id || '').localeCompare(a.id || '');
        });

        if (contador) {
          contador.textContent = lista.length
            ? ('Exibindo ' + lista.length + ' chamado' + (lista.length !== 1 ? 's' : '') + '.')
            : '';
        }

        if (lista.length === 0) {
          const temChamados = todosChamados.length > 0;
          container.innerHTML = '<div class="resolver-vazio-wrap">' +
            '<div class="resolver-vazio-icone" aria-hidden="true"><svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg></div>' +
            '<p class="resolver-vazio-titulo">' + (temChamados ? 'Nenhum resultado' : 'Nada por aqui') + '</p>' +
            '<p class="resolver-vazio-txt">' + (temChamados
              ? 'Nenhum chamado corresponde à busca ou aos filtros. Tente limpar a pesquisa ou incluir finalizados.'
              : 'Não há chamados cadastrados. Abra um chamado ou veja a listagem completa.') + '</p>' +
            '<p class="resolver-vazio-links"><a href="listagem-chamados.html" class="botao botao-outline">Listagem</a> <a href="abrir-chamado.html" class="botao">Abrir chamado</a></p>' +
            '</div>';
          return;
        }

        container.innerHTML = lista.map(montarHtmlCardResolver).join('');
        container.querySelectorAll('.form-resolver-chamado').forEach(function(form) {
          form.addEventListener('submit', async function(ev) {
            ev.preventDefault();
            const cid = form.getAttribute('data-chamado-id');
            const atual = todosChamados.find(function(x) { return x.id === cid; }) || getChamadoPorId(cid);
            const statusAtual = form.getAttribute('data-status-atual') || (atual ? padronizarStatus(atual.status || '') : '');
            const statusNovo = padronizarStatus(form.querySelector('[name="status_novo"]').value);
            const obs = form.querySelector('[name="observacao"]').value.trim();
            if (statusNovo.toLowerCase().includes('finalizado') && !obs) {
              alert('Para finalizar, descreva como o chamado foi resolvido.');
              return;
            }
            if (statusNovo === statusAtual && !obs) {
              alert('Altere o status ou informe a descrição da resolução.');
              return;
            }

            const partes = [];
            if (statusNovo !== statusAtual) partes.push('Status atualizado para "' + statusNovo + '".');
            if (obs) partes.push(obs);
            const textoTr = partes.join(' ');

            let atualizouNaApi = false;
            try {
              await apiRequest('/chamados/' + encodeURIComponent(cid), {
                method: 'PATCH',
                body: JSON.stringify({ status: statusNovo, resolucao: obs })
              });
              atualizouNaApi = true;
            } catch (apiErr) {
              if (apiErr && apiErr.status && apiErr.status < 500) {
                alert(apiErr.message || 'Não foi possível atualizar o chamado na API.');
                return;
              }
              if (!podeUsarFallbackLocal(apiErr)) {
                alert(apiErr.message || 'API indisponível para atualizar o chamado.');
                return;
              }
              showPageNotice('API indisponível. Alterações serão salvas localmente.', 'alerta');
            }

            if (!atualizouNaApi) {
              const atualLocal = getChamadoPorId(cid);
              if (!atualLocal) return;
              salvarChamadoParcial(cid, {
                status: statusNovo,
                resolucao: obs || atualLocal.resolucao
              });
              adicionarTramitacao(cid, {
                texto: textoTr,
                porNome: null,
                porEmail: null
              });
            }

            form.querySelector('[name="observacao"]').value = '';
            mostrarToastResolver('Chamado ' + cid + ' atualizado.');
            await renderizarPaginaResolver();
          });
        });
      }

      const chkFin = document.getElementById('resolver-mostrar-finalizados');
      if (chkFin) chkFin.addEventListener('change', function() { renderizarPaginaResolver(); });
      const busca = document.getElementById('resolver-busca');
      if (busca) busca.addEventListener('input', function() { renderizarPaginaResolver(); });
      const filSel = document.getElementById('resolver-filtro-status');
      if (filSel) filSel.addEventListener('change', function() { renderizarPaginaResolver(); });
      renderizarPaginaResolver();
    })();

    /* --- Listagem de chamados ---
     * Preenche a tabela com os chamados do localStorage.
     * Cada linha tem link para detalhes-chamado.html?id=XXXX.
     */
    const tbodyChamados = document.querySelector('.tabela-container tbody');
    if (tbodyChamados) {
      const usuarioAtualListagem = getUsuarioSessaoAtual();
      const isAdminListagem = usuarioEhAdministrador(usuarioAtualListagem);
      const elBusca = document.getElementById('lista-busca');
      const elStatus = document.getElementById('lista-status');
      const elPrioridade = document.getElementById('lista-prioridade');
      const elSetor = document.getElementById('lista-setor');
      const elResumo = document.getElementById('lista-resumo');
      const elVazio = document.getElementById('lista-vazio');
      const elPaginacao = document.getElementById('lista-paginacao');
      const btnLimpar = document.getElementById('lista-limpar-filtros');
      const btnVazioLimpar = document.getElementById('lista-vazio-limpar');
      const totalColunasTabela = isAdminListagem ? 8 : 7;
      var paginaAtual = 1;
      const porPagina = 8;
      var todosChamados = [];

      function popularSetores(chamados) {
        if (!elSetor) return;
        var vistos = {};
        var setores = [];
        chamados.forEach(function(c) {
          [c.setorOrigem, c.setorDestino].forEach(function(s) {
            var nome = (s || '').trim();
            if (!nome) return;
            var chave = normalizarTextoBase(nome);
            if (vistos[chave]) return;
            vistos[chave] = true;
            setores.push(nome);
          });
        });
        setores.sort(function(a, b) { return a.localeCompare(b, 'pt-BR'); });
        elSetor.innerHTML = '<option value="">Todos</option>' +
          setores.map(function(s) { return '<option value="' + escapeHtmlStr(normalizarTextoBase(s)) + '">' + escapeHtmlStr(s) + '</option>'; }).join('');
      }

      function matchFiltrosListagem(c) {
        const busca = (elBusca?.value || '').trim().toLowerCase();
        const fStatus = elStatus?.value || '';
        const fPrioridade = elPrioridade?.value || '';
        const fSetor = elSetor?.value || '';
        const statusNorm = normalizarTextoBase(padronizarStatus(c.status));
        const prioridadeNorm = normalizarTextoBase(padronizarPrioridade(c.prioridade));
        const origemNorm = normalizarTextoBase(c.setorOrigem || '');
        const destinoNorm = normalizarTextoBase(c.setorDestino || '');
        if (fStatus && !statusNorm.includes(fStatus)) return false;
        if (fPrioridade && !prioridadeNorm.includes(fPrioridade)) return false;
        if (fSetor && origemNorm !== fSetor && destinoNorm !== fSetor) return false;
        if (busca) {
          const blob = [c.id, c.tipo, c.setorOrigem, c.setorDestino, c.status, c.prioridade, c.descricao || ''].join(' ').toLowerCase();
          if (!blob.includes(busca)) return false;
        }
        return true;
      }

      function renderPaginacao(total) {
        if (!elPaginacao) return;
        const totalPaginas = Math.max(1, Math.ceil(total / porPagina));
        if (paginaAtual > totalPaginas) paginaAtual = totalPaginas;
        if (total <= porPagina) {
          elPaginacao.innerHTML = '';
          return;
        }
        var html = '';
        html += '<button type="button" data-page="' + (paginaAtual - 1) + '"' + (paginaAtual === 1 ? ' disabled' : '') + '>Anterior</button>';
        for (var p = 1; p <= totalPaginas; p++) {
          html += '<button type="button" data-page="' + p + '" class="' + (p === paginaAtual ? 'is-active' : '') + '">' + p + '</button>';
        }
        html += '<button type="button" data-page="' + (paginaAtual + 1) + '"' + (paginaAtual === totalPaginas ? ' disabled' : '') + '>Próxima</button>';
        elPaginacao.innerHTML = html;
        elPaginacao.querySelectorAll('button[data-page]').forEach(function(btn) {
          btn.addEventListener('click', function() {
            const alvo = Number(btn.getAttribute('data-page'));
            if (!alvo || alvo === paginaAtual) return;
            paginaAtual = alvo;
            renderTabelaChamados(todosChamados);
          });
        });
      }

      const renderTabelaChamados = function(chamados) {
        var filtrados = chamados.filter(matchFiltrosListagem);
        const total = filtrados.length;
        const ini = (paginaAtual - 1) * porPagina;
        const fim = ini + porPagina;
        var visiveis = filtrados.slice(ini, fim);
        if (elResumo) {
          elResumo.textContent = total
            ? ('Exibindo ' + (ini + 1) + '–' + Math.min(fim, total) + ' de ' + total + ' chamado(s).')
            : 'Nenhum chamado encontrado com os filtros atuais.';
        }
        if (elVazio) elVazio.hidden = total !== 0;
        if (elPaginacao) renderPaginacao(total);
        tbodyChamados.innerHTML = visiveis.map(function(c) {
          const statusLabel = padronizarStatus(c.status || 'Aberto');
          const prioridadeLabel = padronizarPrioridade(c.prioridade || '-');
          const statusClass = classeStatusChamado(statusLabel);
          const priorClass = (normalizarTextoBase(prioridadeLabel).includes('alta') || normalizarTextoBase(prioridadeLabel).includes('critica')) ? 'prioridade-alta' :
            normalizarTextoBase(prioridadeLabel).includes('media') ? 'prioridade-media' : 'prioridade-baixa';
          var nAnexos = (c.anexos && c.anexos.length) ? c.anexos.length : 0;
          var colAnexo = nAnexos ? '<span class="tabela-anexo-sim" title="' + nAnexos + ' arquivo(s)">' + nAnexos + '</span>' : '—';
          var colAcoes = isAdminListagem
            ? ('<button type="button" class="botao botao-outline" data-chamado-delete="' + escapeHtmlStr(String(c.id)) + '">Excluir</button>')
            : '—';
          return '<tr><td><a href="detalhes-chamado.html?id=' + encodeURIComponent(c.id) + '" class="link-tabela">' + c.id + '</a></td>' +
            '<td>' + (c.setorOrigem || '-') + '</td><td>' + (c.setorDestino || '-') + '</td>' +
            '<td><span class="status ' + statusClass + '">' + statusLabel + '</span></td>' +
            '<td class="' + priorClass + '">' + prioridadeLabel + '</td>' +
            '<td>' + (c.prazo || '-') + '</td>' +
            '<td class="tabela-col-anexo">' + colAnexo + '</td>' +
            '<td>' + colAcoes + '</td></tr>';
        }).join('');
      };

      function limparFiltros() {
        if (elBusca) elBusca.value = '';
        if (elStatus) elStatus.value = '';
        if (elPrioridade) elPrioridade.value = '';
        if (elSetor) elSetor.value = '';
        paginaAtual = 1;
        renderTabelaChamados(todosChamados);
      }

      (async function carregarChamadosTabela() {
        tbodyChamados.innerHTML = '<tr><td colspan="' + totalColunasTabela + '">Carregando chamados...</td></tr>';
        try {
          const data = await apiRequest('/chamados');
          if (data && Array.isArray(data.chamados)) {
            todosChamados = filtrarChamadosPorUsuario(data.chamados);
            popularSetores(todosChamados);
            renderTabelaChamados(todosChamados);
            return;
          }
        } catch (apiErr) {
          if (podeUsarFallbackLocal(apiErr)) {
            showPageNotice('API indisponível no momento. Exibindo dados locais.', 'alerta');
          } else {
            showPageNotice('Falha ao carregar chamados pela API.', 'erro');
            todosChamados = [];
            renderTabelaChamados(todosChamados);
            return;
          }
        }
        todosChamados = filtrarChamadosPorUsuario(initChamados());
        popularSetores(todosChamados);
        renderTabelaChamados(todosChamados);
      })();

      [elBusca, elStatus, elPrioridade, elSetor].forEach(function(el) {
        if (!el) return;
        el.addEventListener('input', function() { paginaAtual = 1; renderTabelaChamados(todosChamados); });
        el.addEventListener('change', function() { paginaAtual = 1; renderTabelaChamados(todosChamados); });
      });
      if (btnLimpar) btnLimpar.addEventListener('click', limparFiltros);
      if (btnVazioLimpar) btnVazioLimpar.addEventListener('click', limparFiltros);
      if (isAdminListagem) {
        tbodyChamados.addEventListener('click', async function(ev) {
          const btnDelete = ev.target.closest('button[data-chamado-delete]');
          if (!btnDelete) return;
          const chamadoId = String(btnDelete.getAttribute('data-chamado-delete') || '').trim();
          if (!chamadoId) return;
          const confirma = window.confirm('Tem certeza que deseja excluir o chamado ' + chamadoId + '? Esta ação não pode ser desfeita.');
          if (!confirma) return;
          try {
            setButtonLoading(btnDelete, true, 'Excluindo...');
            await apiRequest('/chamados/' + encodeURIComponent(chamadoId), {
              method: 'DELETE'
            });
            todosChamados = todosChamados.filter(function(c) { return String(c.id) !== chamadoId; });
            paginaAtual = 1;
            popularSetores(todosChamados);
            renderTabelaChamados(todosChamados);
            showToastGlobal('Chamado excluído com sucesso. Backup registrado na auditoria.', 'sucesso');
          } catch (apiErr) {
            showToastGlobal(apiErr.message || 'Não foi possível excluir o chamado.', 'erro');
          } finally {
            setButtonLoading(btnDelete, false);
          }
        });
      }
    }

    /* --- Detalhes do chamado ---
     * Lê o parâmetro id da URL e preenche a página com os dados do chamado.
     * Atualiza cabeçalho, meta, tipo, data de abertura e descrição.
     */
    const urlParams = new URLSearchParams(window.location.search);
    const chamadoId = urlParams.get('id');
    if (chamadoId && document.querySelector('.detalhes-cabecalho')) {
      const formResolverDetalhe = document.getElementById('form-resolver-detalhe');
      const selectStatusDetalhe = document.getElementById('detalhe-status-novo');
      const textResolucaoDetalhe = document.getElementById('detalhe-resolucao');

      const preencherDetalhesChamado = function(chamado) {
        document.querySelector('.detalhes-cabecalho h2').textContent = 'Chamado ' + chamado.id;
        const statusLabel = padronizarStatus(chamado.status || 'Aberto');
        const prioridadeLabel = padronizarPrioridade(chamado.prioridade || '-');
        const statusCl = classeStatusChamado(statusLabel);
        const prioridadeClass = (normalizarTextoBase(prioridadeLabel).includes('alta') || normalizarTextoBase(prioridadeLabel).includes('critica'))
          ? 'prioridade-alta'
          : normalizarTextoBase(prioridadeLabel).includes('media')
            ? 'prioridade-media'
            : 'prioridade-baixa';
        document.querySelector('.detalhes-meta').innerHTML =
          'Setor solicitante: ' + chamado.setorOrigem + ' — Setor responsável: ' + chamado.setorDestino + ' — ' +
          '<span class="status ' + statusCl + '">' + statusLabel + '</span> — Prioridade: <span class="' + prioridadeClass + '">' + prioridadeLabel + '</span> — Prazo: ' + chamado.prazo;

        var tagEnvio = document.getElementById('detalhe-tag-envio');
        var tagResposta = document.getElementById('detalhe-tag-resposta');
        var tagAnexos = document.getElementById('detalhe-tag-anexos');
        var tagProcedimento = document.getElementById('detalhe-tag-procedimento');
        var tagComentario = document.getElementById('detalhe-tag-comentario');
        if (tagEnvio) {
          var quemEnviou = chamado.solicitanteNome || chamado.solicitanteEmail || 'Não identificado';
          tagEnvio.textContent = quemEnviou + ' • ' + (chamado.dataAbertura || '-');
        }
        if (tagResposta) {
          tagResposta.textContent = chamado.resolucao || 'Aguardando resposta do chamado.';
        }
        if (tagProcedimento) {
          tagProcedimento.textContent = chamado.tipo || '-';
        }
        if (tagComentario) {
          tagComentario.textContent = chamado.descricao || '-';
        }
        if (tagAnexos) {
          var anexosTag = Array.isArray(chamado.anexos) ? chamado.anexos : [];
          if (!anexosTag.length) {
            tagAnexos.innerHTML = '<span class="resolver-muted">Sem anexos enviados.</span>';
          } else {
            tagAnexos.innerHTML = anexosTag.map(function(a, i) {
              if (!a || !a.nome) return '';
              var urlAnexo = a.conteudo || a.url || '';
              if (urlAnexo) {
                return montarLinkAnexo(a.nome, urlAnexo, 'detalhe-tag-anexo-link', 'Anexo ' + (i + 1));
              }
              return '<span class="detalhe-tag-anexo-link">Anexo ' + (i + 1) + ': ' + escapeHtmlStr(a.nome) + ' (sem visualização disponível)</span>';
            }).filter(Boolean).join('');
          }
        }
        const blocoInfo = document.getElementById('bloco-info-solicitacao');
        if (blocoInfo) {
          const ps = blocoInfo.querySelectorAll('p');
          if (ps[0]) ps[0].innerHTML = '<strong>Tipo:</strong> ' + (chamado.tipo || '-');
          if (ps[1]) ps[1].innerHTML = '<strong>Data de abertura:</strong> ' + (chamado.dataAbertura || '-');

          var elSol = document.getElementById('detalhe-solicitante');
          if (chamado.solicitanteEmail || chamado.solicitanteNome) {
            if (!elSol) {
              elSol = document.createElement('p');
              elSol.id = 'detalhe-solicitante';
              ps[1].insertAdjacentElement('afterend', elSol);
            }
            var solNome = chamado.solicitanteNome || (chamado.solicitanteEmail ? chamado.solicitanteEmail.split('@')[0] : '');
            elSol.innerHTML = '<strong>Solicitante:</strong> ' + escapeHtmlStr(solNome) +
              (chamado.solicitanteEmail ? ' <span style="color:var(--text-muted)">(' + escapeHtmlStr(chamado.solicitanteEmail) + ')</span>' : '');
          } else if (elSol) {
            elSol.remove();
          }

          var psF = blocoInfo.querySelectorAll('p');
          var idxDesc = (chamado.solicitanteEmail || chamado.solicitanteNome) ? 3 : 2;
          if (psF[idxDesc]) psF[idxDesc].innerHTML = '<strong>Descrição:</strong>';
          if (psF[idxDesc + 1]) psF[idxDesc + 1].textContent = chamado.descricao || '-';
        }

        var blocoAnexosEl = document.getElementById('bloco-anexos-chamado');
        var blocoInfoAlvo = document.getElementById('bloco-info-solicitacao');
        if (chamado.anexos && chamado.anexos.length && blocoInfoAlvo) {
          if (!blocoAnexosEl) {
            blocoAnexosEl = document.createElement('section');
            blocoAnexosEl.className = 'bloco-info';
            blocoAnexosEl.id = 'bloco-anexos-chamado';
            blocoInfoAlvo.insertAdjacentElement('afterend', blocoAnexosEl);
          }
          blocoAnexosEl.innerHTML = '<h3>Anexos</h3><ul class="lista-anexos-detalhe">' +
            chamado.anexos.map(function(a) {
              var link = '';
              if (a && (a.conteudo || a.url)) {
                var href = a.conteudo || a.url;
                link = ' ' + montarLinkAnexo(a.nome || 'anexo', href, 'link-tabela', 'Visualizar');
              }
              return '<li><span class="anexo-nome">' + escapeHtmlStr(a.nome) + '</span> ' +
                '<span class="anexo-meta">(' + formatarTamanhoArquivo(a.tamanho) + ')</span>' + link + '</li>';
            }).join('') + '</ul>' +
            '<p class="campo-ajuda campo-ajuda-anexo">Anexos com conteúdo salvo podem ser abertos em nova guia.</p>';
          blocoAnexosEl.style.display = '';
        } else if (blocoAnexosEl) {
          blocoAnexosEl.style.display = 'none';
          blocoAnexosEl.innerHTML = '';
        }

        var secStatus = document.getElementById('bloco-status-atual');
        if (secStatus) {
          var pSt = secStatus.querySelector('p');
          if (pSt) {
            var txt = 'Situação atual: <strong>' + escapeHtmlStr(padronizarStatus(chamado.status || '-')) + '</strong>.';
            if (chamado.encaminhadoPara && (chamado.encaminhadoPara.nome || chamado.encaminhadoPara.email)) {
              var er = chamado.encaminhadoPara;
              txt += ' Encaminhado para <strong>' + escapeHtmlStr(er.nome || er.email || '') + '</strong>';
              if (er.email) txt += ' <span style="color:var(--text-muted)">(' + escapeHtmlStr(er.email) + ')</span>';
              txt += '.';
            }
            if (chamado.resolucao) {
              txt += ' <br><strong>Resolução:</strong> ' + escapeHtmlStr(chamado.resolucao);
            }
            pSt.innerHTML = txt;
          }
        }

        var contTr = document.getElementById('detalhes-tramitacao-conteudo');
        if (contTr) {
          contTr.classList.add('timeline');
          var trs = chamado.tramitacao && chamado.tramitacao.length ? chamado.tramitacao : [];
          if (trs.length === 0) {
            contTr.innerHTML = '<div class="historico-item"><span class="data">—</span><p>Nenhum registro de tramitação ainda.</p></div>';
          } else {
            contTr.innerHTML = trs.map(function(t) {
              var por = '';
              if (t.porNome || t.porEmail) {
                por = ' <span class="tram-por">— ' + escapeHtmlStr(t.porNome || '') +
                  (t.porEmail ? ' (' + escapeHtmlStr(t.porEmail) + ')' : '') + '</span>';
              }
              return '<div class="historico-item"><span class="data">' + escapeHtmlStr(formatarQuandoTramitacao(t.quando)) + '</span><p>' + escapeHtmlStr(t.texto || '') + por + '</p></div>';
            }).join('');
          }
        }

        if (selectStatusDetalhe) {
          selectStatusDetalhe.value = padronizarStatus(chamado.status || 'Aberto');
        }
        if (textResolucaoDetalhe) {
          textResolucaoDetalhe.value = chamado.resolucao || '';
        }
      };

      async function atualizarChamadoPeloDetalhe(idChamado, statusNovo, obs) {
        let uOp = null;
        try {
          const raw = sessionStorage.getItem(STORAGE_KEYS.usuario);
          uOp = raw ? JSON.parse(raw) : null;
        } catch (_e) { /* ignore */ }
        const atual = getChamadoPorId(idChamado);
        const statusAtual = atual ? padronizarStatus(atual.status || '') : '';
        const partes = [];
        if (statusNovo !== statusAtual) partes.push('Status atualizado para "' + statusNovo + '".');
        if (obs) partes.push(obs);
        if (statusNovo.toLowerCase().includes('finalizado') && !obs) {
          showToastGlobal('Para finalizar, descreva como o chamado foi resolvido.', 'erro');
          return false;
        }
        if (partes.length === 0) {
          showToastGlobal('Altere o status ou informe a descrição da resolução.', 'erro');
          return false;
        }
        const textoTr = partes.join(' ');
        let atualizouNaApi = false;
        try {
          await apiRequest('/chamados/' + encodeURIComponent(idChamado), {
            method: 'PATCH',
            body: JSON.stringify({ status: statusNovo, resolucao: obs })
          });
          atualizouNaApi = true;
        } catch (apiErr) {
          if (apiErr && apiErr.status && apiErr.status < 500) {
            showToastGlobal(apiErr.message || 'Não foi possível atualizar o chamado na API.', 'erro');
            return false;
          }
          if (!podeUsarFallbackLocal(apiErr)) {
            showToastGlobal(apiErr.message || 'API indisponível para atualizar o chamado.', 'erro');
            return false;
          }
          showPageNotice('API indisponível. Alterações foram salvas localmente.', 'alerta');
        }
        if (!atualizouNaApi) {
          const atualLocal = getChamadoPorId(idChamado);
          if (!atualLocal) return false;
          salvarChamadoParcial(idChamado, {
            status: statusNovo,
            resolucao: obs || atualLocal.resolucao
          });
          adicionarTramitacao(idChamado, {
            texto: textoTr,
            porNome: uOp ? (uOp.nome || (uOp.email ? uOp.email.split('@')[0] : '')) : null,
            porEmail: uOp ? uOp.email : null
          });
        }
        showToastGlobal('Chamado ' + idChamado + ' atualizado com sucesso.', 'sucesso');
        return true;
      }

      (async function carregarDetalhesChamado() {
        const usuarioAtual = getUsuarioSessaoAtual();
        try {
          const data = await apiRequest('/chamados/' + encodeURIComponent(chamadoId));
          if (data && data.chamado) {
            if (!chamadoVisivelParaUsuario(data.chamado, usuarioAtual)) {
              showPageNotice('Você não tem permissão para visualizar este chamado.', 'erro');
              return;
            }
            preencherDetalhesChamado(data.chamado);
            return;
          }
        } catch (apiErr) {
          if (podeUsarFallbackLocal(apiErr)) {
            showPageNotice('API indisponível no momento. Exibindo dados locais.', 'alerta');
          } else {
            showPageNotice('Falha ao carregar detalhes do chamado pela API.', 'erro');
            return;
          }
        }

        let chamados = filtrarChamadosPorUsuario(getChamados(), usuarioAtual);
        if (chamados.length === 0) {
          initChamados();
          chamados = filtrarChamadosPorUsuario(getChamados(), usuarioAtual);
        }
        const chamadoLocal = chamados.find(function(c) { return c.id === chamadoId; });
        if (chamadoLocal) preencherDetalhesChamado(chamadoLocal);
        else showPageNotice('Chamado não encontrado ou sem permissão de acesso.', 'erro');
      })();

      if (formResolverDetalhe) {
        formResolverDetalhe.addEventListener('submit', async function(ev) {
          ev.preventDefault();
          const statusNovo = selectStatusDetalhe ? selectStatusDetalhe.value : '';
          const obs = textResolucaoDetalhe ? textResolucaoDetalhe.value.trim() : '';
          const btn = formResolverDetalhe.querySelector('button[type="submit"]');
          setButtonLoading(btn, true, 'Salvando...');
          try {
            const ok = await atualizarChamadoPeloDetalhe(chamadoId, statusNovo, obs);
            if (ok) {
              try {
                const data = await apiRequest('/chamados/' + encodeURIComponent(chamadoId));
                if (data && data.chamado) preencherDetalhesChamado(data.chamado);
              } catch (_eRefresh) {
                const local = getChamadoPorId(chamadoId);
                if (local) preencherDetalhesChamado(local);
              }
            }
          } finally {
            setButtonLoading(btn, false);
          }
        });
      }
    }

    /* --- Dashboard: métricas ---
     * Calcula a quantidade de chamados por status e atualiza os cards.
     * Abertos, Em atendimento e Finalizados.
     */
    const cardsMetricas = document.querySelector('.cards-metricas');
    if (cardsMetricas) {
      const valAbertos = cardsMetricas.querySelector('.card-metrica:not(.amarelo):not(.verde) .valor');
      const valAtend = cardsMetricas.querySelector('.card-metrica.amarelo .valor');
      const valFinal = cardsMetricas.querySelector('.card-metrica.verde .valor');
      const METRICAS_REFRESH_MS = 15000;
      let avisoApiIndisponivelMostrado = false;
      let avisoErroApiMostrado = false;
      const setMetricas = function(abertos, atendimento, finalizados) {
        if (valAbertos) valAbertos.textContent = abertos;
        if (valAtend) valAtend.textContent = atendimento;
        if (valFinal) valFinal.textContent = finalizados;
      };
      const calcularMetricasLocais = function() {
        const chamados = filtrarChamadosPorUsuario(initChamados());
        const abertos = chamados.filter(function(c) { return (c.status || '').toLowerCase().includes('aberto'); }).length;
        const atendimento = chamados.filter(function(c) { return (c.status || '').toLowerCase().includes('atendimento'); }).length;
        const finalizados = chamados.filter(function(c) { return (c.status || '').toLowerCase().includes('finalizado'); }).length;
        setMetricas(abertos, atendimento, finalizados);
      };

      const carregarMetricas = async function() {
        try {
          const data = await apiRequest('/dashboard/metricas');
          if (data && typeof data.abertos === 'number') {
            setMetricas(data.abertos, data.emAtendimento || 0, data.finalizados || 0);
            avisoApiIndisponivelMostrado = false;
            avisoErroApiMostrado = false;
            return;
          }
        } catch (apiErr) {
          if (podeUsarFallbackLocal(apiErr)) {
            if (!avisoApiIndisponivelMostrado) {
              showPageNotice('API indisponível no momento. Exibindo métricas locais.', 'alerta');
              avisoApiIndisponivelMostrado = true;
            }
            avisoErroApiMostrado = false;
            calcularMetricasLocais();
            return;
          } else {
            if (!avisoErroApiMostrado) {
              showPageNotice('Falha ao carregar métricas pela API.', 'erro');
              avisoErroApiMostrado = true;
            }
            avisoApiIndisponivelMostrado = false;
            return;
          }
        }
      };

      carregarMetricas();
      const metricaInterval = window.setInterval(carregarMetricas, METRICAS_REFRESH_MS);
      document.addEventListener('visibilitychange', function() {
        if (!document.hidden) carregarMetricas();
      });
      window.addEventListener('beforeunload', function() {
        window.clearInterval(metricaInterval);
      }, { once: true });
    }

    /* --- Administração: usuários ---
     * Lista usuários do sistema (rota restrita a administrador).
     */
    const tabelaUsuarios = document.getElementById('admin-usuarios-tbody');
    if (tabelaUsuarios) {
      const buscaEl = document.getElementById('admin-usuarios-busca');
      const perfilEl = document.getElementById('admin-usuarios-perfil');
      const setorEl = document.getElementById('admin-usuarios-setor');
      const ativoEl = document.getElementById('admin-usuarios-ativo');
      const resumoEl = document.getElementById('admin-usuarios-resumo');
      const vazioEl = document.getElementById('admin-usuarios-vazio');
      const limparEl = document.getElementById('admin-usuarios-limpar');
      const auditoriaTbody = document.getElementById('admin-auditoria-tbody');
      let usuariosCache = [];
      let setoresCatalogo = [];

      function getUsuarioSessaoAdmin() {
        try {
          const raw = sessionStorage.getItem(STORAGE_KEYS.usuario);
          return raw ? JSON.parse(raw) : null;
        } catch (_err) {
          return null;
        }
      }

      function opcoesPerfil(selected) {
        const perfis = ['solicitante', 'atendente', 'coordenador', 'administrador'];
        return perfis.map(function(p) {
          const sel = String(selected || '') === p ? ' selected' : '';
          return '<option value="' + p + '"' + sel + '>' + p + '</option>';
        }).join('');
      }

      function opcoesSetor(selectedId) {
        const current = Number(selectedId || 0);
        const base = ['<option value="">Selecione</option>'];
        setoresCatalogo.forEach(function(s) {
          const sel = Number(s.id) === current ? ' selected' : '';
          base.push('<option value="' + escapeHtmlStr(String(s.id)) + '"' + sel + '>' + escapeHtmlStr(String(s.nome)) + '</option>');
        });
        return base.join('');
      }

      function preencherFiltroSetor(usuarios) {
        if (!setorEl) return;
        const nomes = [];
        if (setoresCatalogo.length) {
          setoresCatalogo.forEach(function(s) {
            const nome = String(s.nome || '').trim();
            if (nome && nomes.indexOf(nome) === -1) nomes.push(nome);
          });
        } else {
          usuarios.forEach(function(u) {
            const nome = String(u.setor_nome || '').trim();
            if (nome && nomes.indexOf(nome) === -1) nomes.push(nome);
          });
        }
        nomes.sort(function(a, b) { return a.localeCompare(b, 'pt-BR'); });
        setorEl.innerHTML = '<option value="">Todos os setores</option>' +
          nomes.map(function(nome) {
            return '<option value="' + escapeHtmlStr(normalizarTextoBase(nome)) + '">' + escapeHtmlStr(nome) + '</option>';
          }).join('');
      }

      function renderUsuarios(lista) {
        tabelaUsuarios.innerHTML = '';
        if (!Array.isArray(lista) || !lista.length) {
          if (vazioEl) vazioEl.hidden = false;
          if (resumoEl) resumoEl.textContent = 'Nenhum usuário encontrado.';
          return;
        }
        if (vazioEl) vazioEl.hidden = true;
        if (resumoEl) resumoEl.textContent = lista.length + ' usuário(s) listado(s).';
        lista.forEach(function(u) {
          const tr = document.createElement('tr');
          const setor = u.setor_nome || '—';
          const perfil = u.perfil || '—';
          const ativo = u.ativo ? 'Ativo' : 'Inativo';
          const ultimo = u.ultimo_acesso
            ? new Date(u.ultimo_acesso).toLocaleString('pt-BR')
            : 'Nunca';
          tr.innerHTML =
            '<td>' + escapeHtmlStr(u.nome || '—') + '</td>' +
            '<td>' + escapeHtmlStr(u.email || '—') + '</td>' +
            '<td><select data-user-setor class="admin-user-select">' + opcoesSetor(u.setor_id) + '</select></td>' +
            '<td><select data-user-perfil class="admin-user-select">' + opcoesPerfil(perfil) + '</select></td>' +
            '<td><label style="display:flex;align-items:center;gap:.45rem;"><input data-user-ativo type="checkbox"' + (u.ativo ? ' checked' : '') + '> <span>' + escapeHtmlStr(ativo) + '</span></label></td>' +
            '<td>' + escapeHtmlStr(ultimo) + '</td>' +
            '<td style="display:flex;gap:.4rem;flex-wrap:wrap;">' +
              '<button type="button" class="botao botao-outline" data-user-save="' + escapeHtmlStr(String(u.id)) + '">Salvar</button>' +
              '<button type="button" class="botao botao-outline" data-user-reset-senha="' + escapeHtmlStr(String(u.id)) + '">Resetar senha</button>' +
              '<button type="button" class="botao botao-outline" data-user-delete="' + escapeHtmlStr(String(u.id)) + '">Excluir</button>' +
            '</td>';
          tabelaUsuarios.appendChild(tr);
        });
      }

      function aplicarFiltrosUsuarios() {
        const termo = normalizarTextoBase(buscaEl ? buscaEl.value : '');
        const perfil = normalizarTextoBase(perfilEl ? perfilEl.value : '');
        const setor = normalizarTextoBase(setorEl ? setorEl.value : '');
        const ativo = normalizarTextoBase(ativoEl ? ativoEl.value : '');
        const filtrados = usuariosCache.filter(function(u) {
          const blob = [
            u.nome || '',
            u.email || '',
            u.perfil || '',
            u.setor_nome || '',
            u.setor_codigo || ''
          ].join(' ');
          if (termo && !normalizarTextoBase(blob).includes(termo)) return false;
          if (perfil && normalizarTextoBase(u.perfil || '') !== perfil) return false;
          if (setor && normalizarTextoBase(u.setor_nome || '') !== setor) return false;
          if (ativo) {
            const status = u.ativo ? 'ativo' : 'inativo';
            if (status !== ativo) return false;
          }
          return true;
        });
        renderUsuarios(filtrados);
      }

      async function carregarUsuariosAdmin() {
        try {
          const resultados = await Promise.all([
            apiRequest('/usuarios'),
            carregarSetoresAtivos().catch(function() { return []; })
          ]);
          const data = resultados[0];
          setoresCatalogo = Array.isArray(resultados[1]) ? resultados[1] : [];
          usuariosCache = Array.isArray(data.usuarios) ? data.usuarios : [];
          if (!setoresCatalogo.length) {
            setoresCatalogo = usuariosCache
              .filter(function(u) { return u.setor_id && u.setor_nome; })
              .map(function(u) { return { id: u.setor_id, nome: u.setor_nome }; });
          }
          preencherFiltroSetor(usuariosCache);
          aplicarFiltrosUsuarios();
        } catch (apiErr) {
          if (apiErr && apiErr.status === 403) {
            showPageNotice('Acesso restrito. Esta página é exclusiva para administradores.', 'erro');
            setTimeout(function() { window.location.replace('dashboard.html'); }, 1200);
            return;
          }
          showPageNotice(apiErr.message || 'Não foi possível carregar os usuários.', 'erro');
        }
      }

      function formatarAcaoAuditoria(acao, detalhesJson) {
        const a = String(acao || '').toLowerCase();
        const d = detalhesJson && typeof detalhesJson === 'object' ? detalhesJson : null;
        if (a === 'alteracao_status' && d && d.exclusao) return 'Exclusão de usuário';
        if (a === 'alteracao_perfil') return 'Alteração de perfil';
        if (a === 'alteracao_setor') return 'Alteração de setor';
        if (a === 'alteracao_status') return 'Ativação/Inativação';
        if (a === 'reset_senha') return 'Reset de senha';
        return acao || 'Ação';
      }

      function renderAuditoria(lista) {
        if (!auditoriaTbody) return;
        auditoriaTbody.innerHTML = '';
        if (!Array.isArray(lista) || !lista.length) {
          auditoriaTbody.innerHTML = '<tr><td colspan="5">Sem registros recentes.</td></tr>';
          return;
        }
        lista.forEach(function(item) {
          const tr = document.createElement('tr');
          const quando = item.criado_em ? new Date(item.criado_em).toLocaleString('pt-BR') : '—';
          const d = item.detalhes_json && typeof item.detalhes_json === 'object' ? item.detalhes_json : null;
          const alvo = item.alvo_nome || item.alvo_email || (d ? (d.alvo_nome || d.alvo_email) : '') || ('ID ' + (item.usuario_alvo_id || '—'));
          const admin = item.admin_nome || item.admin_email || ('ID ' + (item.usuario_admin_id || '—'));
          let detalhes = '—';
          if (d) {
            if (d.antes != null || d.depois != null) {
              detalhes = String(d.antes) + ' -> ' + String(d.depois);
            } else if (d.depois_nome) {
              detalhes = 'Novo setor: ' + String(d.depois_nome);
            } else if (d.reset_por_admin) {
              detalhes = 'Senha redefinida por administrador';
            } else if (d.exclusao) {
              detalhes = 'Conta excluída por administrador';
            }
          }
          tr.innerHTML =
            '<td>' + escapeHtmlStr(quando) + '</td>' +
            '<td>' + escapeHtmlStr(formatarAcaoAuditoria(item.acao, d)) + '</td>' +
            '<td>' + escapeHtmlStr(alvo) + '</td>' +
            '<td>' + escapeHtmlStr(admin) + '</td>' +
            '<td>' + escapeHtmlStr(detalhes) + '</td>';
          auditoriaTbody.appendChild(tr);
        });
      }

      async function carregarAuditoriaUsuarios() {
        if (!auditoriaTbody) return;
        try {
          const data = await apiRequest('/usuarios/auditoria?limit=30');
          renderAuditoria(Array.isArray(data.auditoria) ? data.auditoria : []);
        } catch (_errAud) {
          renderAuditoria([]);
        }
      }

      tabelaUsuarios.addEventListener('click', async function(ev) {
        const btn = ev.target.closest('button[data-user-save]');
        const btnReset = ev.target.closest('button[data-user-reset-senha]');
        const btnDelete = ev.target.closest('button[data-user-delete]');
        const botaoAcao = btn || btnReset || btnDelete;
        if (!botaoAcao) return;
        const userId = Number(
          btn
            ? btn.getAttribute('data-user-save')
            : (btnReset ? btnReset.getAttribute('data-user-reset-senha') : btnDelete.getAttribute('data-user-delete'))
        );
        if (!Number.isInteger(userId) || userId <= 0) return;

        const row = botaoAcao.closest('tr');
        if (!row) return;

        const usuarioSessao = getUsuarioSessaoAdmin();

        if (btnReset) {
          const senha = window.prompt('Digite a nova senha temporária (8+ chars, maiúscula, minúscula e número):');
          if (!senha) return;
          try {
            setButtonLoading(btnReset, true, 'Salvando...');
            await apiRequest('/usuarios/' + encodeURIComponent(String(userId)), {
              method: 'PATCH',
              body: JSON.stringify({ senha_nova: senha })
            });
            showToastGlobal('Senha redefinida com sucesso.', 'sucesso');
            await carregarAuditoriaUsuarios();
          } catch (apiErr) {
            showToastGlobal(apiErr.message || 'Não foi possível redefinir a senha.', 'erro');
          } finally {
            setButtonLoading(btnReset, false);
          }
          return;
        }

        if (btnDelete) {
          if (usuarioSessao && Number(usuarioSessao.id) === userId) {
            showToastGlobal('Você não pode excluir sua própria conta.', 'erro');
            return;
          }
          const confirmou = window.confirm('Tem certeza que deseja excluir este usuário? Esta ação não pode ser desfeita.');
          if (!confirmou) return;
          try {
            setButtonLoading(btnDelete, true, 'Excluindo...');
            await apiRequest('/usuarios/' + encodeURIComponent(String(userId)), {
              method: 'DELETE'
            });
            usuariosCache = usuariosCache.filter(function(u) {
              return Number(u.id) !== userId;
            });
            preencherFiltroSetor(usuariosCache);
            aplicarFiltrosUsuarios();
            showToastGlobal('Usuário excluído com sucesso.', 'sucesso');
            await carregarAuditoriaUsuarios();
          } catch (apiErr) {
            showToastGlobal(apiErr.message || 'Não foi possível excluir o usuário.', 'erro');
          } finally {
            setButtonLoading(btnDelete, false);
          }
          return;
        }

        const perfilSel = row.querySelector('select[data-user-perfil]');
        const setorSel = row.querySelector('select[data-user-setor]');
        const ativoChk = row.querySelector('input[data-user-ativo]');
        const payload = {
          perfil: perfilSel ? perfilSel.value : 'solicitante',
          setor_id: setorSel ? Number(setorSel.value || 0) : 0,
          ativo: !!(ativoChk && ativoChk.checked)
        };
        if (!payload.setor_id) {
          showToastGlobal('Selecione um setor válido antes de salvar.', 'erro');
          return;
        }

        if (usuarioSessao && Number(usuarioSessao.id) === userId && payload.ativo === false) {
          showToastGlobal('Você não pode inativar sua própria conta.', 'erro');
          return;
        }

        try {
          setButtonLoading(btn, true, 'Salvando...');
          const data = await apiRequest('/usuarios/' + encodeURIComponent(String(userId)), {
            method: 'PATCH',
            body: JSON.stringify(payload)
          });
          if (data && data.usuario) {
            usuariosCache = usuariosCache.map(function(u) {
              return Number(u.id) === Number(data.usuario.id) ? data.usuario : u;
            });
            aplicarFiltrosUsuarios();
          }
          showToastGlobal('Usuário atualizado com sucesso.', 'sucesso');
          await carregarAuditoriaUsuarios();
        } catch (apiErr) {
          showToastGlobal(apiErr.message || 'Não foi possível atualizar o usuário.', 'erro');
        } finally {
          setButtonLoading(btn, false);
        }
      });

      if (buscaEl) buscaEl.addEventListener('input', aplicarFiltrosUsuarios);
      if (perfilEl) perfilEl.addEventListener('change', aplicarFiltrosUsuarios);
      if (setorEl) setorEl.addEventListener('change', aplicarFiltrosUsuarios);
      if (ativoEl) ativoEl.addEventListener('change', aplicarFiltrosUsuarios);
      if (limparEl) {
        limparEl.addEventListener('click', function() {
          if (buscaEl) buscaEl.value = '';
          if (perfilEl) perfilEl.value = '';
          if (setorEl) setorEl.value = '';
          if (ativoEl) ativoEl.value = '';
          aplicarFiltrosUsuarios();
        });
      }

      carregarUsuariosAdmin();
      carregarAuditoriaUsuarios();
    }

    /* --- Animação de entrada ---
     * Usa IntersectionObserver para aplicar animação fade-in
     * quando elementos com data-animate entram na área visível.
     */
    const observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fade-in');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

    document.querySelectorAll('[data-animate]').forEach(function(el) {
      el.style.opacity = '0';
      observer.observe(el);
    });
  });
})();

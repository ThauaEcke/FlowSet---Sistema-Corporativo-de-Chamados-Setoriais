const express = require('express');
const { pool } = require('../db');

const router = express.Router();

/** GET /api/setores — lista setores ativos (para formulários). */
router.get('/', async (_req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, codigo, nome, descricao FROM setores WHERE ativo = TRUE ORDER BY nome`
    );
    return res.json({ setores: rows });
  } catch (err) {
    console.error('[setores]', err);
    return res.status(500).json({ error: 'Erro ao listar setores.' });
  }
});

module.exports = router;

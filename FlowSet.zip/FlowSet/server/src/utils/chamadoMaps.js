/** Mapeia valores dos selects do HTML para rótulos gravados no banco (app.js / abrir-chamado.html). */

const TIPO_LABEL = {
  suporte: 'Suporte técnico',
  documentacao: 'Documentação',
  aprovacao: 'Aprovação',
  informacao: 'Solicitação de informação',
  processo: 'Ajuste de processo',
  outro: 'Outro',
};

const PRIORIDADE_LABEL = {
  baixa: 'Baixa',
  media: 'Média',
  alta: 'Alta',
  critica: 'Crítica',
};

function mapTipo(valor) {
  if (!valor || typeof valor !== 'string') return null;
  const k = valor.trim().toLowerCase();
  if (TIPO_LABEL[k]) return TIPO_LABEL[k];
  return valor.trim();
}

function mapPrioridade(valor) {
  if (!valor || typeof valor !== 'string') return null;
  const k = valor.trim().toLowerCase();
  if (PRIORIDADE_LABEL[k]) return PRIORIDADE_LABEL[k];
  return valor.trim();
}

module.exports = { TIPO_LABEL, PRIORIDADE_LABEL, mapTipo, mapPrioridade };

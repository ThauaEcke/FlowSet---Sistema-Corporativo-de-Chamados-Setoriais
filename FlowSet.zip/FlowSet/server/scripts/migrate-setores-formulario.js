const fs = require('fs');
const path = require('path');
const { Client } = require('pg');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

async function main() {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error('DATABASE_URL não configurada em server/.env');
  }
  const sqlPath = path.join(__dirname, '..', 'sql', 'migrate_setores_formulario.sql');
  const sql = fs.readFileSync(sqlPath, 'utf8');

  const client = new Client({ connectionString: databaseUrl });
  await client.connect();
  try {
    await client.query(sql);
    console.log('[migrate] Setores alinhados ao formulário (abrir-chamado).');
  } finally {
    await client.end();
  }
}

main().catch((err) => {
  console.error('[migrate-setores-formulario]', err.message);
  process.exit(1);
});

const jwt = require('jsonwebtoken');
const { pool } = require('../db');

function getJwtSecret() {
  return process.env.JWT_SECRET || 'flowset-dev-altere-em-producao';
}

async function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token não informado. Faça login.' });
  }
  const token = header.slice(7).trim();
  try {
    const payload = jwt.verify(token, getJwtSecret());
    const userId = Number(payload.sub);
    if (!Number.isInteger(userId) || userId <= 0) {
      return res.status(401).json({ error: 'Token inválido.' });
    }
    const { rows } = await pool.query(
      `SELECT id, nome, email, perfil, ativo, setor_id FROM usuarios WHERE id = $1`,
      [userId]
    );
    if (rows.length === 0) {
      return res.status(401).json({ error: 'Usuário do token não encontrado.' });
    }
    const u = rows[0];
    if (u.ativo === false) {
      return res.status(403).json({ error: 'Usuário inativo.' });
    }
    req.user = {
      id: u.id,
      nome: u.nome,
      email: u.email,
      perfil: u.perfil,
      setor_id: u.setor_id,
    };
    next();
  } catch {
    return res.status(401).json({ error: 'Token inválido ou expirado.' });
  }
}

function requirePerfil(...perfisPermitidos) {
  const permitidos = new Set((perfisPermitidos || []).map((p) => String(p || '').trim().toLowerCase()));
  return function(req, res, next) {
    if (!req.user || !req.user.perfil) {
      return res.status(401).json({ error: 'Usuário não autenticado.' });
    }
    const perfilUser = String(req.user.perfil).trim().toLowerCase();
    if (!permitidos.has(perfilUser)) {
      return res.status(403).json({ error: 'Acesso restrito ao perfil administrador.' });
    }
    next();
  };
}

module.exports = { requireAuth, requirePerfil, getJwtSecret };

-- =============================================================================
-- Dados de demonstração (opcional) — alinhados ao app.js / listagem
-- Execute APÓS schema.sql. Remove e reinsere apenas estes números de chamado.
-- =============================================================================

BEGIN;

DELETE FROM chamados WHERE numero IN (
    '2025-0042', '2025-0041', '2025-0040', '2025-0039', '2025-0038', '2025-0037'
);

INSERT INTO chamados (
    numero,
    setor_solicitante_id,
    setor_responsavel_id,
    tipo,
    prioridade,
    descricao,
    prazo,
    status,
    data_abertura
)
SELECT
    dados.numero,
    s_sol.id,
    s_resp.id,
    dados.tipo,
    dados.prioridade,
    dados.descricao,
    dados.prazo,
    dados.status,
    dados.data_abertura
FROM (
    VALUES
        ('2025-0042', 'comercial', 'ti', 'Suporte técnico', 'Alta',
         'Solicitação de suporte para instalação e configuração de ferramentas de vendas.',
         '2025-03-05'::date, 'Em atendimento', '2025-02-20 10:00:00'::timestamptz),
        ('2025-0041', 'rh', 'administrativo-financeiro', 'Documentação', 'Média',
         'Solicitação de documentação.',
         '2025-02-28'::date, 'Finalizado', '2025-02-15 09:00:00'::timestamptz),
        ('2025-0040', 'operacoes', 'administrativo-financeiro', 'Aprovação', 'Baixa',
         'Solicitação de aprovação.',
         '2025-03-10'::date, 'Aberto', '2025-02-18 11:00:00'::timestamptz),
        ('2025-0039', 'atendimento', 'ti', 'Suporte técnico', 'Crítica',
         'Urgência em suporte.',
         '2025-03-01'::date, 'Crítico', '2025-02-25 08:00:00'::timestamptz),
        ('2025-0038', 'administrativo-financeiro', 'rh', 'Solicitação de informação', 'Média',
         'Informações para RH.',
         '2025-02-25'::date, 'Finalizado', '2025-02-10 14:00:00'::timestamptz),
        ('2025-0037', 'administrativo-financeiro', 'operacoes', 'Ajuste de processo', 'Baixa',
         'Ajuste de processo operacional.',
         '2025-03-08'::date, 'Em atendimento', '2025-03-01 16:00:00'::timestamptz)
) AS dados(numero, setor_solicitante_codigo, setor_responsavel_codigo, tipo, prioridade, descricao, prazo, status, data_abertura)
JOIN setores s_sol ON s_sol.codigo = dados.setor_solicitante_codigo
JOIN setores s_resp ON s_resp.codigo = dados.setor_responsavel_codigo;

COMMIT;

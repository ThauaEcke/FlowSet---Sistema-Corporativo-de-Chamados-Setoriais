const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

function readSql(relativePath) {
  const fullPath = path.join(__dirname, '..', relativePath);
  return fs.readFileSync(fullPath, 'utf8');
}

async function main() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error('DATABASE_URL não configurada no arquivo .env');
  }

  const pool = new Pool({ connectionString });
  const client = await pool.connect();

  try {
    console.log('1/3 - Recriando estrutura do banco...');
    await client.query(readSql('sql/schema.sql'));

    console.log('2/3 - Inserindo chamados de demonstração...');
    await client.query(readSql('sql/seed_chamados_demo.sql'));

    console.log('3/3 - Banco pronto para uso.');
    console.log('Nenhum usuário pré-definido foi criado.');
    console.log('Cadastre o primeiro usuário em /registro para gerar o administrador inicial.');
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((err) => {
  console.error('[setup-db] Falha ao preparar banco:', err.message);
  process.exit(1);
});

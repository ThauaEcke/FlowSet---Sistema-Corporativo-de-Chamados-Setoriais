/**
 * Gera o próximo número de chamado no formato AAAA-NNNN (ex.: 2026-0001).
 */
async function gerarProximoNumero(pool) {
  const year = new Date().getFullYear();
  const prefix = `${year}-`;
  const { rows } = await pool.query(
    `SELECT numero FROM chamados WHERE numero LIKE $1`,
    [`${prefix}%`]
  );
  let maxSeq = 0;
  for (const r of rows) {
    const parts = String(r.numero).split('-');
    if (parts.length === 2 && parseInt(parts[0], 10) === year) {
      const n = parseInt(parts[1], 10);
      if (!Number.isNaN(n)) maxSeq = Math.max(maxSeq, n);
    }
  }
  return `${year}-${String(maxSeq + 1).padStart(4, '0')}`;
}

module.exports = { gerarProximoNumero };

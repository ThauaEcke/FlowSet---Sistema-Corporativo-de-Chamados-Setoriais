const path = require('path');
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');

require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

async function main() {
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL não configurada no .env');
  }

  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    await client.query(
      'TRUNCATE TABLE historico, mensagens, chamados, usuarios_auditoria, usuarios RESTART IDENTITY CASCADE'
    );

    const { rows: setorRows } = await client.query(
      'SELECT id FROM setores WHERE codigo = $1 LIMIT 1',
      ['administrativo-financeiro']
    );
    const setorId = setorRows[0] ? setorRows[0].id : null;

    const senhaHash = await bcrypt.hash('Unim@270', 10);

    await client.query(
      `INSERT INTO usuarios (nome, email, senha_hash, perfil, setor_id, ativo)
       VALUES ($1, $2, $3, $4, $5, TRUE)`,
      ['admin unimed', 'admin.unimed@flowset.local', senhaHash, 'administrador', setorId]
    );

    await client.query('COMMIT');
    console.log('Reset concluído: apenas admin unimed criado.');
    console.log('Login: admin.unimed@flowset.local');
    console.log('Senha: Unim@270');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((err) => {
  console.error('[reset-all-data] Falha:', err.message);
  process.exit(1);
});

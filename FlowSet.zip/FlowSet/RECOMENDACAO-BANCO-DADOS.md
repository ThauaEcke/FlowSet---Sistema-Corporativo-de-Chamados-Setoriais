# Recomendação de Banco de Dados — FlowSet

Este documento apresenta a recomendação de banco de dados para integração do sistema FlowSet com backend, incluindo schema SQL e sugestões de tecnologias.

---

## Banco de dados recomendado: **PostgreSQL**

### Por que PostgreSQL?

- **Robustez e confiabilidade**: amplamente usado em ambientes corporativos e em produção.
- **Recursos avançados**: suporte a JSON, full-text search, transações ACID.
- **Custo zero**: software livre e open source.
- **Compatibilidade**: funciona bem com Node.js, Python, PHP e outras linguagens de backend.
- **Escalabilidade**: adequado para o volume de chamados de uma cooperativa como a Unimed.

### Alternativa: **MySQL / MariaDB**

Se a infraestrutura já utilizar MySQL ou MariaDB, o schema abaixo pode ser adaptado com pequenos ajustes (tipos de dados e sintaxe específica).

---

## Schema SQL (PostgreSQL)

```sql
-- ============================================
-- FLOWSET - Schema do banco de dados
-- ============================================

-- Tabela de setores
CREATE TABLE setores (
  id SERIAL PRIMARY KEY,
  codigo VARCHAR(50) UNIQUE NOT NULL,
  nome VARCHAR(100) NOT NULL,
  descricao TEXT,
  ativo BOOLEAN DEFAULT TRUE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inserir setores padrão
INSERT INTO setores (codigo, nome) VALUES
  ('administrativo-financeiro', 'Administrativo / financeiro'),
  ('rh', 'Recursos Humanos'),
  ('ti', 'TI / Tecnologia da Informação'),
  ('operacoes', 'Operações'),
  ('comercial', 'Comercial'),
  ('atendimento', 'Atendimento'),
  ('ser-cadia', 'SER CADIA');

-- Tabela de usuários
CREATE TABLE usuarios (
  id SERIAL PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  senha_hash VARCHAR(255) NOT NULL,
  setor_id INTEGER REFERENCES setores(id),
  perfil VARCHAR(50) DEFAULT 'solicitante', -- solicitante, responsavel, administrador
  ativo BOOLEAN DEFAULT TRUE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  ultimo_acesso TIMESTAMP
);

-- Tabela de chamados
CREATE TABLE chamados (
  id SERIAL PRIMARY KEY,
  numero VARCHAR(20) UNIQUE NOT NULL,        -- ex: 2025-0042
  setor_solicitante_id INTEGER NOT NULL REFERENCES setores(id),
  setor_responsavel_id INTEGER NOT NULL REFERENCES setores(id),
  usuario_abertura_id INTEGER REFERENCES usuarios(id),
  tipo VARCHAR(100) NOT NULL,                 -- Suporte técnico, Documentação, etc.
  prioridade VARCHAR(20) NOT NULL,            -- Baixa, Média, Alta, Crítica
  descricao TEXT NOT NULL,
  prazo DATE,
  status VARCHAR(50) DEFAULT 'Aberto',       -- Aberto, Em atendimento, Finalizado, Crítico
  data_abertura TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  data_conclusao TIMESTAMP,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para consultas frequentes
CREATE INDEX idx_chamados_status ON chamados(status);
CREATE INDEX idx_chamados_setor_sol ON chamados(setor_solicitante_id);
CREATE INDEX idx_chamados_setor_resp ON chamados(setor_responsavel_id);
CREATE INDEX idx_chamados_data ON chamados(data_abertura);

-- Tabela de mensagens (comentários no chamado)
CREATE TABLE mensagens (
  id SERIAL PRIMARY KEY,
  chamado_id INTEGER NOT NULL REFERENCES chamados(id) ON DELETE CASCADE,
  usuario_id INTEGER REFERENCES usuarios(id),
  conteudo TEXT NOT NULL,
  interna BOOLEAN DEFAULT FALSE,             -- mensagem interna (não visível ao solicitante)
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_mensagens_chamado ON mensagens(chamado_id);

-- Tabela de histórico de alterações
CREATE TABLE historico (
  id SERIAL PRIMARY KEY,
  chamado_id INTEGER NOT NULL REFERENCES chamados(id) ON DELETE CASCADE,
  usuario_id INTEGER REFERENCES usuarios(id),
  tipo_alteracao VARCHAR(50) NOT NULL,        -- abertura, mudanca_status, conclusao
  valor_anterior TEXT,
  valor_novo TEXT,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_historico_chamado ON historico(chamado_id);
```

---

## Integração com o frontend

### Fluxo sugerido

1. **Backend (API REST)**: criar uma API em Node.js (Express), Python (Flask/FastAPI) ou PHP que exponha endpoints para:
   - `POST /api/login` — autenticação
   - `POST /api/registro` — cadastro de usuário
   - `GET /api/chamados` — listar chamados (com filtros opcionais)
   - `POST /api/chamados` — abrir novo chamado
   - `GET /api/chamados/:id` — detalhes do chamado
   - `PATCH /api/chamados/:id` — atualizar status
   - `GET /api/dashboard/metricas` — contagem por status

2. **Substituir localStorage**: no `app.js`, trocar as chamadas a `localStorage` por requisições `fetch()` para a API.

3. **Segurança**: usar HTTPS, tokens JWT para sessão e hash de senha (bcrypt) no backend.

---

## Exemplo de endpoint (Node.js + Express)

```javascript
// Exemplo simplificado - GET chamados
app.get('/api/chamados', async (req, res) => {
  const result = await pool.query(`
    SELECT c.*, 
           s1.nome AS setor_origem, 
           s2.nome AS setor_destino
    FROM chamados c
    JOIN setores s1 ON c.setor_solicitante_id = s1.id
    JOIN setores s2 ON c.setor_responsavel_id = s2.id
    ORDER BY c.data_abertura DESC
  `);
  res.json(result.rows);
});
```

---

## Resumo

| Item | Recomendação |
|------|--------------|
| **Banco de dados** | PostgreSQL |
| **Alternativa** | MySQL / MariaDB |
| **Backend** | Node.js (Express) ou Python (FastAPI) |
| **Autenticação** | JWT |
| **Senhas** | Hash com bcrypt |

Para dúvidas ou ajustes no schema, consulte a documentação do PostgreSQL ou adapte conforme as necessidades específicas da Unimed.

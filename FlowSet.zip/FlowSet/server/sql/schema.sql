-- =============================================================================
-- FlowSet — PostgreSQL (modelo v2, orientado a uso profissional)
-- Alinhado à API (Node) e ao front (tipos de chamado, setores, status em PT-BR).
--
-- IMPORTANTE: este script REMOVE as tabelas antigas e recria tudo.
-- Execute em um banco de desenvolvimento (ex.: flowset_test). Faça backup se
-- houver dados que precise manter.
-- =============================================================================

-- (Opcional) Busca textual: CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ---------------------------------------------------------------------------
-- Função: atualiza coluna atualizado_em em UPDATEs
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION flowset_touch_atualizado_em()
RETURNS TRIGGER AS $$
BEGIN
  NEW.atualizado_em := CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------------
-- Remoção do modelo anterior (ordem segura por FKs)
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS historico CASCADE;
DROP TABLE IF EXISTS usuarios_auditoria CASCADE;
DROP TABLE IF EXISTS mensagens CASCADE;
DROP TABLE IF EXISTS chamados CASCADE;
DROP TABLE IF EXISTS usuarios CASCADE;
DROP TABLE IF EXISTS setores CASCADE;

-- ---------------------------------------------------------------------------
-- Setores (códigos estáveis usados na API e no HTML: ti, comercial, …)
-- ---------------------------------------------------------------------------
CREATE TABLE setores (
    id SERIAL PRIMARY KEY,
    codigo VARCHAR(50) NOT NULL,
    nome VARCHAR(120) NOT NULL,
    descricao TEXT,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_setores_codigo UNIQUE (codigo),
    CONSTRAINT chk_setores_codigo_slug CHECK (codigo ~ '^[a-z0-9]+(-[a-z0-9]+)*$')
);

CREATE TRIGGER tr_setores_atualizado_em
    BEFORE UPDATE ON setores
    FOR EACH ROW
    EXECUTE PROCEDURE flowset_touch_atualizado_em();

COMMENT ON TABLE setores IS 'Unidades organizacionais; codigo é chave de integração com o front.';

INSERT INTO setores (codigo, nome) VALUES
    ('administrativo-financeiro', 'Administrativo / financeiro'),
    ('rh', 'Recursos Humanos'),
    ('ti', 'TI / Tecnologia da Informação'),
    ('operacoes', 'Operações'),
    ('comercial', 'Comercial'),
    ('atendimento', 'Atendimento'),
    ('ser-cadia', 'SER CADIA');

-- ---------------------------------------------------------------------------
-- Usuários (autenticação; senha apenas como hash bcrypt na aplicação)
-- ---------------------------------------------------------------------------
CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(200) NOT NULL,
    email VARCHAR(255) NOT NULL,
    senha_hash TEXT NOT NULL,
    setor_id INTEGER REFERENCES setores (id) ON DELETE SET NULL,
    perfil VARCHAR(30) NOT NULL DEFAULT 'solicitante',
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ultimo_acesso TIMESTAMPTZ,
    CONSTRAINT uq_usuarios_email UNIQUE (email),
    CONSTRAINT chk_usuarios_perfil CHECK (perfil IN (
        'solicitante', 'atendente', 'coordenador', 'administrador'
    )),
    CONSTRAINT chk_usuarios_nome_nao_vazio CHECK (char_length(trim(nome)) > 0)
);

CREATE INDEX idx_usuarios_setor ON usuarios (setor_id) WHERE ativo = TRUE;

CREATE TRIGGER tr_usuarios_atualizado_em
    BEFORE UPDATE ON usuarios
    FOR EACH ROW
    EXECUTE PROCEDURE flowset_touch_atualizado_em();

COMMENT ON TABLE usuarios IS 'Contas de acesso; email único em minúsculas (normalizado na API).';

-- ---------------------------------------------------------------------------
-- Auditoria administrativa de usuários (perfil/setor/status/senha)
-- ---------------------------------------------------------------------------
CREATE TABLE usuarios_auditoria (
    id SERIAL PRIMARY KEY,
    usuario_admin_id INTEGER REFERENCES usuarios (id) ON DELETE SET NULL,
    usuario_alvo_id INTEGER REFERENCES usuarios (id) ON DELETE SET NULL,
    acao VARCHAR(40) NOT NULL,
    detalhes_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_usuarios_auditoria_acao CHECK (acao IN (
        'alteracao_perfil', 'alteracao_setor', 'alteracao_status', 'reset_senha'
    ))
);

CREATE INDEX idx_usuarios_auditoria_alvo ON usuarios_auditoria (usuario_alvo_id, criado_em DESC);
CREATE INDEX idx_usuarios_auditoria_admin ON usuarios_auditoria (usuario_admin_id, criado_em DESC);

COMMENT ON TABLE usuarios_auditoria IS 'Registro de alterações administrativas em contas de usuário.';

-- ---------------------------------------------------------------------------
-- Chamados (número humano AAAA-NNNN; exclusão lógica em excluido_em)
-- ---------------------------------------------------------------------------
CREATE TABLE chamados (
    id SERIAL PRIMARY KEY,
    numero VARCHAR(20) NOT NULL,
    setor_solicitante_id INTEGER NOT NULL REFERENCES setores (id),
    setor_responsavel_id INTEGER NOT NULL REFERENCES setores (id),
    usuario_abertura_id INTEGER REFERENCES usuarios (id) ON DELETE SET NULL,
    tipo VARCHAR(120) NOT NULL,
    prioridade VARCHAR(20) NOT NULL,
    descricao TEXT NOT NULL,
    anexos_json JSONB,
    resolucao_texto TEXT,
    prazo DATE,
    status VARCHAR(40) NOT NULL DEFAULT 'Aberto',
    data_abertura TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_conclusao TIMESTAMPTZ,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    excluido_em TIMESTAMPTZ,
    CONSTRAINT uq_chamados_numero UNIQUE (numero),
    CONSTRAINT chk_chamados_prioridade CHECK (prioridade IN ('Baixa', 'Média', 'Alta', 'Crítica')),
    CONSTRAINT chk_chamados_status CHECK (status IN (
        'Aberto', 'Em atendimento', 'Finalizado', 'Crítico', 'Aguardando', 'Cancelado'
    )),
    CONSTRAINT chk_chamados_descricao CHECK (char_length(trim(descricao)) > 0)
);

CREATE INDEX idx_chamados_listagem ON chamados (data_abertura DESC)
    WHERE excluido_em IS NULL;

CREATE INDEX idx_chamados_status ON chamados (status)
    WHERE excluido_em IS NULL;

CREATE INDEX idx_chamados_setor_sol ON chamados (setor_solicitante_id)
    WHERE excluido_em IS NULL;

CREATE INDEX idx_chamados_setor_resp ON chamados (setor_responsavel_id)
    WHERE excluido_em IS NULL;

CREATE TRIGGER tr_chamados_atualizado_em
    BEFORE UPDATE ON chamados
    FOR EACH ROW
    EXECUTE PROCEDURE flowset_touch_atualizado_em();

COMMENT ON TABLE chamados IS 'Solicitações setoriais; excluido_em preenchido = removido logicamente.';
COMMENT ON COLUMN chamados.numero IS 'Identificador exibido (ex.: 2026-0042).';
COMMENT ON COLUMN chamados.excluido_em IS 'Preenchido para soft delete; registros não são apagados fisicamente.';

-- ---------------------------------------------------------------------------
-- Mensagens / threads no chamado
-- ---------------------------------------------------------------------------
CREATE TABLE mensagens (
    id SERIAL PRIMARY KEY,
    chamado_id INTEGER NOT NULL REFERENCES chamados (id) ON DELETE CASCADE,
    usuario_id INTEGER REFERENCES usuarios (id) ON DELETE SET NULL,
    conteudo TEXT NOT NULL,
    interna BOOLEAN NOT NULL DEFAULT FALSE,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_mensagens_conteudo CHECK (char_length(trim(conteudo)) > 0)
);

CREATE INDEX idx_mensagens_chamado ON mensagens (chamado_id, criado_em DESC);

CREATE TRIGGER tr_mensagens_atualizado_em
    BEFORE UPDATE ON mensagens
    FOR EACH ROW
    EXECUTE PROCEDURE flowset_touch_atualizado_em();

COMMENT ON TABLE mensagens IS 'Comentários e interações vinculadas ao chamado.';

-- ---------------------------------------------------------------------------
-- Histórico de auditoria (status, abertura, etc.)
-- ---------------------------------------------------------------------------
CREATE TABLE historico (
    id SERIAL PRIMARY KEY,
    chamado_id INTEGER NOT NULL REFERENCES chamados (id) ON DELETE CASCADE,
    usuario_id INTEGER REFERENCES usuarios (id) ON DELETE SET NULL,
    tipo_alteracao VARCHAR(40) NOT NULL,
    valor_anterior TEXT,
    valor_novo TEXT,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_historico_tipo CHECK (tipo_alteracao IN (
        'abertura', 'mudanca_status', 'mudanca_prioridade', 'comentario',
        'reabertura', 'exclusao'
    ))
);

CREATE INDEX idx_historico_chamado ON historico (chamado_id, criado_em DESC);

COMMENT ON TABLE historico IS 'Trilha de auditoria para conformidade e suporte.';
